// vim: tabstop=4 shiftwidth=4 cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009
// Based on FindMedianCentre.java, ZTest.java, and Vector.java by Ari Morse and
// Andy Mackenzie

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Set;
import java.util.HashSet;

/** 
 * Uses Ari Morse's original mediancentre-finder to check the new (refactored,
 * arbitrary-dimension) version.
 */
// See also the private OldVector class below
public class LegacyCheck {

	// Pulled from Ari's MyMath
	// Moved here since no new code should *ever* use this horrible kludge
	private static boolean equal(double x, double y){
		
		if(x == 0.0 && y != 0.0)
			return false;
		else if(x != 0.0 && y == 0.0)
			return false;
		else if(x == 0.0 && y == 0.0)
			return true;
		
		String temp1 = x+"";
		String temp2 = y+"";
		
		if(temp1.length() != temp2.length())
			return false;
		
		
		int decimal1 = temp1.indexOf('.');
		int decimal2 = temp2.indexOf('.');
		
		if(decimal1 == -1 && decimal2 == -1){
			if(temp1.compareTo(temp2) == 0)
				return true;
			else
				return false;
		}
		
		if(temp1.length() <= 4 && temp2.length() <= 4){
			if(temp1.compareTo(temp2) == 0)
				return true;
			else
				return false;
		}
			
		
		int e = temp1.indexOf('E');
		if(e == -1){
			temp1 = temp1.substring(0, decimal1) +"." + temp1.substring(decimal1+1, (temp1.length()-2));
			temp2 = temp2.substring(0, decimal2) +"." + temp2.substring(decimal2+1, (temp2.length()-2));
		}
		else{
			temp1 = temp1.substring(0, decimal1) +"." + temp1.substring(decimal1+1, (e-2)) + temp1.substring(e,temp1.length());
			temp2 = temp2.substring(0, decimal2) +"." + temp2.substring(decimal2+1, (e-2)) + temp2.substring(e,temp2.length());
		}
		
		if(temp1.compareTo(temp2) == 0)
			return true;
		else
			return false;
		
	}	
	
	/** Ari Morse's original mediancentre-finder, modified to return the
	 * calculated median rather than the election result derived from it. */
	public static OldVector findMedian(OldVector[] hex, int[] profile, int voters){
		
		boolean found = false;

    	OldVector median = null;
			
		//Checks profiles with two vertex equal that add to an even number
		if(voters%2 == 0){
			int oneV = 0;
			boolean restZero=false;
			for(int k = 0; k < profile.length; k++){
				int l;
				if(profile[k] == 0)
					continue;
				else{
					oneV = profile[k];
					for(l = k+1; l < profile.length; l++){
						if(profile[l] == 0)
							continue;
						else if(profile[l] == oneV){
							int w;
							for(w = l+1; w < profile.length; w++){
								if(profile[w] != 0)
									break;
							}
							if(w == profile.length)
								restZero = true;
							else
								break;
						}
						else //non zero number not equal to oneV
							break;
					}
					if(l < profile.length)
						break;
				}
			}
			if(restZero){
				return null;
			}
		}
			
			
			
		// Setting the weights based on the profile
		for(int j = 0; j < hex.length; j++){
			hex[j].weight = profile[j];
		}
		
		//CHECKING THE VERTICES OF THE HEX FOR THE MEAN
		//ADD UP THE OTHER 5 Unit Vectors and if the magnitude
		//is less than or equal to one, then that vertex is the mean
		OldVector sum = new OldVector();
		for(int i = 0; i < hex.length; i++){
			if(hex[i].weight==0)
				continue;
			else{
				for(int j = i+1; j != i; j++){
					if (j == hex.length)
						j = -1;
					else{
						OldVector temp = (OldVector.subtract(hex[j],hex[i]));
						temp.normalize();
						sum = OldVector.add(sum, OldVector.multiply(temp, hex[j].weight));
					}
				}//for j
				if(sum.magnitude() <= hex[i].weight){
					median = hex[i];
					found = true;
					break;
				}
				else
					found = false;
			}//else	1
			sum.vec[0] = 0;
			sum.vec[1] = 0;
			sum.vec[2] = 0;
		}//for i
		
		if(found)
			return median;
		
		OldVector y = findMean(hex,voters);
		double previousMagnitude = 0;
		double twoPreviousMagnitude = 0;
		double magnitude = 0;
		
		
		double percentage1 = 13;
		double percentage2 = 13;
  
		
		while(true){
			for(int i = 0; i < hex.length; i++){
				OldVector temp = (OldVector.subtract(hex[i],y));
				temp.normalize();
				sum = OldVector.add(sum, OldVector.multiply(temp, hex[i].weight));
			}
			twoPreviousMagnitude = previousMagnitude;
			previousMagnitude = magnitude;
			magnitude = sum.magnitude();
			
			if(magnitude == 0){
				median = y;
				break;
			}
			else if(magnitude == previousMagnitude || magnitude == twoPreviousMagnitude){
				
				if(percentage1 > 0){
					double newY0 = sum.vec[0]*(percentage1/100);
					double newY1 = sum.vec[1]*(percentage1/100);
					double newY2 = sum.vec[2]*(percentage1/100);
					
					if(newY0 < Math.pow(10, -16) && newY0 > -1*Math.pow(10, -16))
						y.vec[0] = y.vec[0]+0;
					else
						y.vec[0] = y.vec[0]+newY0; 
					
					if(newY1 < Math.pow(10, -16) && newY1 > -1*Math.pow(10, -16))
						y.vec[1] = y.vec[1]+0;
					else
						y.vec[1] = y.vec[1]+newY1;
					
					if(newY2 < Math.pow(10, -16) && newY2 > -1*Math.pow(10, -16))
						y.vec[2] = y.vec[2]+0;
					else
						y.vec[2] = y.vec[2]+newY2; 
					
					percentage1 -= 2;
				}
				else{
					
				median = y;
				break;
				}
			}
			else if(equal(magnitude, previousMagnitude) || 
					equal(magnitude, twoPreviousMagnitude)){
				
				if(percentage2 > 0){
					double newY0 = sum.vec[0]*(percentage2/100);
					double newY1 = sum.vec[1]*(percentage2/100);
					double newY2 = sum.vec[2]*(percentage2/100);
					
					if(newY0 < Math.pow(10, -16) && newY0 > -1*Math.pow(10, -16))
						y.vec[0] = y.vec[0]+0;
					else
						y.vec[0] = y.vec[0]+newY0; 
					
					if(newY1 < Math.pow(10, -16) && newY1 > -1*Math.pow(10, -16))
						y.vec[1] = y.vec[1]+0;
					else
						y.vec[1] = y.vec[1]+newY1;
					
					if(newY2 < Math.pow(10, -16) && newY2 > -1*Math.pow(10, -16))
						y.vec[2] = y.vec[2]+0;
					else
						y.vec[2] = y.vec[2]+newY2; 
					
					percentage2 -= 2;
				}
				else{
					median = y;
					break;
				}
			}
			else if(magnitude < Math.pow(10, -13)){ //-13
				median = y;
				break;
			}
			else{
				double newY0 = sum.vec[0]*.15;
				double newY1 = sum.vec[1]*.15;
				double newY2 = sum.vec[2]*.15;
				
				if(newY0 < Math.pow(10, -16) && newY0 > -1*Math.pow(10, -16))
					y.vec[0] = y.vec[0]+0;
				else
					y.vec[0] = y.vec[0]+newY0; 
				
				if(newY1 < Math.pow(10, -16) && newY1 > -1*Math.pow(10, -16))
					y.vec[1] = y.vec[1]+0;
				else
					y.vec[1] = y.vec[1]+newY1;
				
				if(newY2 < Math.pow(10, -16) && newY2 > -1*Math.pow(10, -16))
					y.vec[2] = y.vec[2]+0;
				else
					y.vec[2] = y.vec[2]+newY2;
			}
			sum.vec[0] = 0;
			sum.vec[1] = 0;
			sum.vec[2] = 0;

		}

		return median;
	}

	public static OldVector findMean(OldVector[] hex, int numVoters){
		double sum=0;
		
		OldVector result = new OldVector();
		for(int j = 0; j < 3; j++){
			for(int k = 0; k < hex.length; k++){
				sum += (hex[k].vec[j]*hex[k].weight);
			}
			result.vec[j] = sum/numVoters;
			sum = 0;
		}

		return result;
	}

	public static String determineWinner(OldVector[] hex, OldVector y, int[]profile){
		
		double firstDot = y.dotProduct(hex[2]);
		double secondDot = y.dotProduct(hex[0]);
		double thirdDot = y.dotProduct(hex[1]);
		
		String return_str ="";
		
		String result = "";
		
		if(firstDot > Math.pow(10, -15))
			result += "+";
		else if (firstDot < -1*Math.pow(10, -15))
			result += "-";
		else
			result += "0";
		
		if(secondDot > Math.pow(10, -15))
			result += "+";
		else if (secondDot < -1*Math.pow(10, -15))
			result += "-";
		else
			result += "0";
		
		if(thirdDot > Math.pow(10, -15))
			result += "+";
		else if (thirdDot < -1*Math.pow(10, -15))
			result += "-";
		else
			result += "0";
		
		if(result.compareTo("---") == 0)
			return_str = "PQR";
		else if(result.compareTo("+--") == 0)
			return_str = "PRQ";
		else if(result.compareTo("++-") == 0)
			return_str = "RPQ";
		else if(result.compareTo("+++") == 0)
			return_str = "RQP";
		else if(result.compareTo("-++") == 0)
			return_str = "QRP";
		else if(result.compareTo("--+") == 0)
			return_str = "QPR";

		else if(result.compareTo("0--") == 0){
			return_str = "PQRPRQ";
		}
		else if(result.compareTo("+0-") == 0){
			return_str = "PRQRPQ";
		}
		else if(result.compareTo("++0") == 0){
			return_str = "RPQRQP";
		}
		else if(result.compareTo("0++") == 0){
			return_str = "RQPQRP";
		}
		else if(result.compareTo("-0+") == 0){
			return_str = "QRPQPR";
		}
		else if(result.compareTo("--0") == 0){
			return_str = "PQRQPR";
		}
		else if(result.compareTo("000") == 0){
			return_str = "PQRPRQRPQRQPQRPQPR";
		}
		
		return return_str;
	}

	/** Convert the output of determineWinner() to a set of the winning
	 * garrisoned ballots (the format of MedianRule.winning_ballots_by). */
	private static Set<Vector> convert_result(String old_style) {
		int[] ranks = {2, 0, -2};
		int[] comp = new int[3];
		int num_ballots = old_style.length()/3;

		Set<Vector> ballots = new HashSet<Vector>();
		for (int ballot = 0; ballot < num_ballots; ballot++) {
			String ballot_str = old_style.substring(ballot*3, (ballot+1)*3);

			for (int rank = 0; rank < ballot_str.length(); rank++) {
				int alternative = ballot_str.charAt(rank) - 'P';
				comp[alternative] = ranks[rank];
			}

			ballots.add(new Vector(comp));
		}

		return ballots;
	}

	/** Parse list of integers in a string and return it as an int[]. */
	private static int[] parse_int_list(String source) {
		String[] split = source.split("[ \t]+");
		int[] parsed = new int[split.length];
		for (int i = 0; i < split.length; i++) {
			parsed[i] = Integer.parseInt(split[i]);
		}
		return parsed;
	}

	/** Read, from standard input, profiles for elections with 3 alternatives
	 * and output the mediancentre as calculated by the old and new algorithms,
	 * giving a warning if they don't match within a reasonable margin. */
	public static void main(String[] args) {
		boolean error = false;

		OldVector[] vertexes_old = new OldVector[6];
		vertexes_old[5] = new OldVector(2,0,-2);
		vertexes_old[4] = new OldVector(2,-2,0);
		vertexes_old[3] = new OldVector(0,2,-2);
		vertexes_old[2] = new OldVector(0,-2,2);
		vertexes_old[1] = new OldVector(-2,2,0);
		vertexes_old[0] = new OldVector(-2,0,2);
		Ballots new_ballots = new Ballots(3);

		BufferedReader input = new BufferedReader(
				new InputStreamReader(System.in));
		String profile_str;
		try {
			profile_str = input.readLine();
		} catch (IOException ioe) {
			System.exit(255);
			return; // Keep the compiler quiet
		}

		while (profile_str != null) {
			int[] profile = parse_int_list(profile_str);
			if (profile.length != 6) {
				System.exit(255);
			}

			int sum = 0;
			for (int i = 0; i < profile.length; i++) {
				sum += profile[i];
			}

			System.out.println(profile_str);

			OldVector median_old_raw = findMedian(vertexes_old, profile, sum);
			Vector median_old = null;
			if (median_old_raw != null) {
				median_old = new Vector(median_old_raw.vec);
			}
			ProfileAnalyzer new_analyzer =
				new ProfileAnalyzer(profile, new_ballots);
			new_analyzer.optimize_median_estimate();
			Vector median_new = new_analyzer.get_median_estimate();
			if (median_new.is_nav()) {
				median_new = null;
			}

			System.out.print("    Old: " + median_old);
			Set<Vector> old_outcome = null;
			double old_sum_of_dists = 0;
			if (median_old != null) {
				String old_outcome_raw = determineWinner(vertexes_old,
							median_old_raw, profile);
				old_outcome = convert_result(old_outcome_raw);
				old_sum_of_dists = new_analyzer.sum_of_dists_at(median_old);
				System.out.print(" (sum: " + old_sum_of_dists + ", outcome: " +
						old_outcome_raw + " aka " + 
						old_outcome + ")");
			}

			System.out.println();

			System.out.print("    New: " + median_new);
			Set<Vector> new_outcome = null;
			double new_sum_of_dists = 0;
			if (median_new != null) {
				OutcomeAnalyzer outcome_analyzer = 
					new OutcomeAnalyzer(median_new, new_ballots);
				String new_outcome_pretty = outcome_analyzer.toString();
				new_outcome = outcome_analyzer.get_winning_ballots();
				new_sum_of_dists = new_analyzer.get_sum_of_dists();
				System.out.print(" (sum: " + new_sum_of_dists + ", outcome: " +
						new_outcome_pretty + " aka " + new_outcome + ")");
			}
			System.out.println();

			if ((median_old == null) != (median_new == null)) {
				System.out.println("    Mismatch!");
				error = true;
			} else if (median_old != null && median_new != null) {
				System.out.print("    ");
				Vector median_diff = median_new.sub(median_old);
				double dist_diff = new_sum_of_dists - old_sum_of_dists;
				System.out.print("diff: " + median_diff + " ");
				System.out.print("dist-diff: " + dist_diff + " ");
				System.out.println();

				if (dist_diff > Math.pow(10, -13)) {
					System.out.println("    Error: sum-of-dists regression.");
					error = true;
				}

				if (! new_outcome.equals(old_outcome) ) {
					System.out.println("    Outcome mismatch!");
					error = true;
				}
			}

			System.out.println();

			try {
				profile_str = input.readLine();
			} catch (IOException ioe) {
				System.exit(255);
				return; // Keep the compiler quiet
			}
		}

		if (error) {
			System.out.println("Error detected.");
			System.exit(1);
		}

	}

}

// Ari Morse's version of Vector
// Moved and renamed by Daniel Gnoutcheff, Summer 2009
class OldVector
{
   public double vec[];
   public double weight;
   private int occurances;
   private int[] profile = new int[6];

   public OldVector() 
   {
      vec = new double[3];
      weight = 0;
      occurances = 1;
   }

   public OldVector(double v0, double v1, double v2)
   {
      vec = new double[3];
      vec[0] = v0;
      vec[1] = v1;
      vec[2] = v2;
      weight = 0;
      occurances = 1;
   }
   
   public void setProfile(int[]p){
	   profile = p;
   }
   
   public int[] getProfile(){
	   return profile;
   }
   
   public String printProfile(){
	   String result ="";
	   
	   for(int i = 0; i < profile.length;i++)
		   result += profile[i] + " ";
	   
	   return result;
   }
   
   public void increaseOccurances(){
	   occurances++;
   }
   
   public int getNumberOccurances(){
	   return occurances;
   }
   
   public static OldVector copyVector(OldVector v1){
	   OldVector result = new OldVector();
	   result.vec[0] = v1.vec[0];
	   result.vec[1] = v1.vec[1];
	   result.vec[2] = v1.vec[2];
	   return result;
   }
   
   public static OldVector multiply(OldVector v1, double x){
	   OldVector result = new OldVector();
	   result.vec[0] = v1.vec[0]*x;
	   result.vec[1] = v1.vec[1]*x;
	   result.vec[2] = v1.vec[2]*x;
	   return result;
   }
   
   public static OldVector subtract(OldVector v1, OldVector v2){
	   OldVector result = new OldVector();
	   result.vec[0] = v1.vec[0]-v2.vec[0];
	   result.vec[1] = v1.vec[1]-v2.vec[1];
	   result.vec[2] = v1.vec[2]-v2.vec[2];
	   return result;
   }
   
   public static OldVector add(OldVector v1, OldVector v2){
	   OldVector result = new OldVector();
	   result.vec[0] = v1.vec[0]+v2.vec[0];
	   result.vec[1] = v1.vec[1]+v2.vec[1];
	   result.vec[2] = v1.vec[2]+v2.vec[2];
	   return result;
   }

   // compute the cross product: (the "calling" vector) x v2
   public OldVector crossProduct(OldVector v2)
   {
       OldVector result = new OldVector();
       result.vec[0] = this.vec[1] * v2.vec[2] - this.vec[2] * v2.vec[1];
       result.vec[1] = this.vec[2] * v2.vec[0] - this.vec[0] * v2.vec[2];
       result.vec[2] = this.vec[0] * v2.vec[1] - this.vec[1] * v2.vec[0];
       return result;
   }

   // compute the cross product: v1 x v2
   public static OldVector crossProduct(OldVector v1, OldVector v2)
   {
       OldVector result = new OldVector();
       result.vec[0] = v1.vec[1] * v2.vec[2] - v1.vec[2] * v2.vec[1];
       result.vec[1] = v1.vec[2] * v2.vec[0] - v1.vec[0] * v2.vec[2];
       result.vec[2] = v1.vec[0] * v2.vec[1] - v1.vec[1] * v2.vec[0];
       return result;
   }

   // compute the dot product: (the "calling" vector) . v2
   public double dotProduct(OldVector v2)
   {
       return (this.vec[0] * v2.vec[0] +
               this.vec[1] * v2.vec[1] +
               this.vec[2] * v2.vec[2]);
   }

   // compute the dot product: v1 . v2
   public static double dotProduct(OldVector v1, OldVector v2)
   {
       return (v1.vec[0] * v2.vec[0] +
               v1.vec[1] * v2.vec[1] +
               v1.vec[2] * v2.vec[2]);
   }

   // compute the magnitude of the vector
   public double magnitude()
   {
       double result = Math.sqrt(this.vec[0]*this.vec[0] +
                        this.vec[1]*this.vec[1] +
                        this.vec[2]*this.vec[2]);
       return result;
   }

   // normalize the vector
   // this method makes the vector have magnitude 1
   public void normalize()
   {
	double mag = magnitude();
	vec[0] = vec[0] / mag;
	vec[1] = vec[1] / mag;
	vec[2] = vec[2] / mag;
   }
   
   public boolean compare(OldVector y){
	   return this.vec[0]==y.vec[0] && this.vec[1]==y.vec[1]
	             && this.vec[2]==y.vec[2];
   }
  

   public String toString()
   {
        String result="";
        for (int i=0; i<2; i++)
		result += vec[i] + ", ";
	result += vec[2];
	return result;
   }
}


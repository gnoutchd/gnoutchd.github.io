// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.util.Arrays;

/** A way to use MyMath.permute from the command-line. Used for testing. */
public class PermuTest {
    public static void main(String[] args) {
        int[] elements = new int[args.length];
        for (int i = 0; i < elements.length; i++) {
            elements[i] = Integer.parseInt(args[i]);
        }

        int[][] permu = MyMath.permute(elements);
        for (int i = 0; i < permu.length; i++) {
            int[] curr_permu = permu[i];
            int reverse = MyMath.permute_index_of(curr_permu, elements);
            System.out.println(Arrays.toString(permu[i]));
            if (reverse != i) {
                System.out.println("Index mismatch! Should be " + i + ", got " +
                        reverse);
                return;
            }
        }
    }
}

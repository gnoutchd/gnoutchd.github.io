// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.io.*;

/** A collection of functions to feed profiles into a given ProfileSink. */
public class ProfileSource {
     /** Parse list of integers in a string and return it as an int[]. */
    private static int[] parse_int_list(String source) {
        if (source == null) {
            return null;
        }
        String[] split = source.split("[ \t]+");
        int[] parsed = new int[split.length];
        for (int i = 0; i < split.length; i++) {
            try {
                parsed[i] = Integer.parseInt(split[i]);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return parsed;
    }
    
    /** Read in a line, return null if we hit a problem */
    public static String read_line(BufferedReader input) {
        try {
            return input.readLine();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Read profile data from standard input and output to standard output. */
    public static void stdio(ProfileSink sink) {
        BufferedReader input = 
            new BufferedReader(new InputStreamReader(System.in));
        PrintWriter output = 
            new PrintWriter(new IndentedWriter(
                        new OutputStreamWriter(System.out)));
        boolean warning = false;

        String profile_str = read_line(input);
        int[] profile = parse_int_list(profile_str);
        while (profile != null) {
            System.out.println(profile_str);
            
            boolean issue_found = sink.process_profile(profile, output);
            if (issue_found) {
                warning = true;
            }

            output.flush();
            System.out.println();

            profile_str = read_line(input);
            profile = parse_int_list(profile_str);
        }

        if (warning) {
            System.out.println("Issue found.");
        }
    }
}

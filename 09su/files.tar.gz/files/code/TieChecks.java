// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.util.Set;
import java.io.PrintWriter;

// TODO: make SymCheck return Vector.NaV to be consistent with ProfileAnalyzer?
public class TieChecks implements ProfileSink {
    Ballots ballots;
    SymCheck sym;

    public TieChecks() {
        ballots = new Ballots(3);
        sym = new SymCheck(ballots);
    }

    public boolean process_profile(int[] profile, PrintWriter out) {
        ProfileAnalyzer analyzer = new ProfileAnalyzer(profile, ballots);
        analyzer.optimize_median_estimate();
        Vector median = analyzer.get_median_estimate();
        boolean warning = false;

        if (!median.is_nav()) {
            OutcomeAnalyzer median_outcome 
                = new OutcomeAnalyzer(median, ballots);
            
            Set<Vector> median_winning = median_outcome.get_winning_ballots();
            String median_desc = median_outcome.toString();
            out.println("ProfileAnalyzer: " + median_desc); 

            Vector tie_check = sym.check(profile);
            if (tie_check != null) {
                OutcomeAnalyzer tie_outcome = 
                    new OutcomeAnalyzer(tie_check, ballots);
                String tie_desc = tie_outcome.toString();

                out.println("       SymCheck: " + tie_desc);

                if (! tie_desc.equals(median_desc)) {
                    out.println("Mismatch.");
                    warning = true;
                } else {
                    out.println("Sucessful tie.");
                }
            } else {
                out.println("       SymCheck: undefined");
                if (median_winning.size() != 1) {
                    out.println("Mismatch (unexpected tie).");
                    warning = true;
                }
            }
        } else {
            out.println("ProfileAnalyzer: undefined");
        }

        return warning;
    }

    public int num_alternatives() {
        return 3;
    }

    public static void main(String[] args) {
        TieChecks checker = new TieChecks();
        ProfileSource.stdio(checker);
    }
}

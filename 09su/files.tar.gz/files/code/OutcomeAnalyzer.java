// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009
// Based on FindMedianCentre.java by Ari Morse and Andy Mackenzie

// We import everything manually to make it clear that we *don't* use 
// java.util.Vector anywhere, 'Vector' refers to our own class.
import java.util.Collection;
import java.util.Set;
import java.util.SortedMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.HashSet;
import java.util.Collections;

/** Represents a "center" (mean or mediancentre) and interprets the election
 * outcome on the basis of that center. */
public class OutcomeAnalyzer {
    /** How different two components must be for us to consider them distinct.
     * */
    private final double EQUALITY_THRESHOLD = Math.pow(10, -5);
    /** The center under analysis */
    private Vector center;
    /** The set of ballots used to interpret this center. */
    private Ballots ballots;
    /** The ID numbers of the alternatives who win according to the center. null
     * if not yet calculated. */
    private int[] winning_alternatives;
    /** Partition of the alternatives, in ascending order of preference ranking.
     * Each set of this partition contains equally-ranked alternatives. null if
     * not yet calculated */
    private Collection<Set<Integer>> alternative_partition;
    /** Set of winning ballots under the center. null if not yet calculated. */
    private Set<Vector> winning_ballots;
    /** String description of this outcome. null if not yet calculated. */
    private String description;

    /** Analyze the given "average" according to the given ballot set. */
    public OutcomeAnalyzer(Vector new_center, Ballots new_ballots) {
        int num_comp = new_center.numComp();
        if (num_comp != 0 && num_comp != new_ballots.get_dimension()) {
            throw new IllegalArgumentException("Expected " + 
                    new_ballots.get_dimension() + " components, got " +
                    new_center.numComp());
        }

        center = new_center;
        ballots = new_ballots;
    }

    /** Get the "center" point being analyzed. */
    public Vector get_center() {
        return center;
    }

    /** Return an array containing the ID numbers of the alternatives who are
     * considered winners when the mean or mediancentre is at the given point.
     * This array is sorted in ascending order. The alternatives are identified
     * by the indexes of the vector components that they correspond to.
     */
    public int[] get_winners() {
        if (winning_alternatives == null && ! center.is_nav()) {
            winning_alternatives = find_winners();
        }

        if (winning_alternatives == null) {
            return null;
        } else {
            return winning_alternatives.clone();
        }
    }

    /** Generate the list of winning alternatives, according to the center */
    private int[] find_winners() {
        if (center.is_nav()) {
            return null;
        }

        // We return the indexes of the components with the highest values. Each
        // component corresponds to an alternative. We determine the winner(s)
        // by considering the ordering induced by the given mediancentre
        // estimate.

        ArrayList<Integer> comps = new ArrayList<Integer>();
        comps.add(0);
        double max = center.getComp(0);

        for (int c = 1; c < center.numComp(); c++) {
            double comp_val = center.getComp(c);
            if (Math.abs(comp_val - max) < EQUALITY_THRESHOLD) {
                comps.add(c);
            } else if (comp_val > max) {
                comps.clear();
                max = comp_val;
                comps.add(c);
            }
        }

        return MyMath.to_primitive(comps.toArray(new Integer[0]));
    }

    /** Calculate the partition of alternatives. You want to use get_partition,
     * which caches the output of this method. See get_partition for the
     * descriptions of the output of this method. */
    private Collection<Set<Integer>> generate_partition() {
        int alternatives = center.numComp();
        SortedMap<Estimate, Set<Integer>> partition = 
            new TreeMap<Estimate, Set<Integer>>();

        // Add each alternative to the appropriate set in the partition
        for (int alt = 0; alt < alternatives; alt++) {
            Estimate raw_rank = new Estimate(center.getComp(alt),
                    EQUALITY_THRESHOLD/2);

            Set<Integer> set = partition.get(raw_rank);
            // If a set for this ranking doesn't yet exist, create it
            if (set == null) {
                set = new HashSet<Integer>();
                partition.put(raw_rank, set);
            }

            set.add(alt);
        }

        // Discard the map's keys (the raw rank values)
        return partition.values();
    }

    /** Get all the sets of equally-ranked alternatives.
     *
     * @return a partition of all the alternatives (each alternative represented
     * by the integer that is the index of the vector component associated with
     * that alternative). The sets of alternatives are returned by this
     * collection's iterator in ascending order of preference.
     */
    private Collection<Set<Integer>> get_partition() {
        if (alternative_partition == null && !center.is_nav()) {
            alternative_partition = generate_partition();
        }

        return alternative_partition;
    }


    /** Represents a set of alternatives tied for the same preference ranking
     * and helps permute these alternatives so as to find all the winning
     * ballots. */
    // This is a helper class for generate_winning_ballots(Vector)
    private class TiedAltPermutations {
        /** The number of alternatives ranked below the alternatives in this
         * instance. */
        private int num_below;
        /** The possible permutations of the alternatives in question. */
        private int[][] permutations;
        /** The index of the permutation currently under consideration. */
        private int curr_permu;
        /** The (garrisoned) ballot we are permuting, represented as the
         * components of the location of this  ballot. Stored as an array rather
         * than a Vector so as to allow modification. */
        public int[] ballot;

        /** Prepare to permute the given set of tied alternatives, all ranked
         * above the given number of alternatives, and prepare to permute these
         * alternatives as they are represented on the given ballot. */
        private TiedAltPermutations(Set<Integer> alternatives, int below, 
                int[] ballot_to_permute) {
            ballot = ballot_to_permute;
            num_below = below;
            permutations = MyMath.permute(
                    MyMath.to_primitive(alternatives.toArray(new Integer[0])));
            goto_first_permutation();
        }

        /** Are there no more permutations to consider? */
        private boolean at_last_permutation() {
            return curr_permu == permutations.length - 1;
        }

        /** Advance to the next permutation of these alternatives. */
        private void goto_next_permutation() {
            if (at_last_permutation()) {
                throw new IllegalStateException();
            }
            curr_permu++;
            write_to_ballot();
        }

        /** Return to the first (reference) permutation. */
        private void goto_first_permutation() {
            curr_permu = 0;
            write_to_ballot();
        }

        /** Record the alternatives, in the order specified by the current
         * permutation, into the ballot. */
        private void write_to_ballot() {
            int[] permutation = permutations[curr_permu];

            for (int i = 0; i < permutation.length; i++) {
                ballot[permutation[i]] = ballots.get_rank(num_below + i);
            }
        }
    }

    /** Generate TiedAltPermutations objects from the given rank-wise partition
     * of the alternatives. This is done in preparation for generating the set
     * of winning ballots. Note that the total number of alternatives in the
     * partition must */
    private TiedAltPermutations[]
    generate_permutations(Collection<Set<Integer>> partition, int[] ballot) {

        Iterator<Set<Integer>> partition_iter = partition.iterator();
        int num_sets = partition.size();
        TiedAltPermutations[] set_permutations =
            new TiedAltPermutations[num_sets];

        // Number of alternatives added to set_permutations so far
        int alternative_counter = 0;

        // Copy each set into the appropriate set_permutations entry
        for (int set_index = 0; set_index < num_sets; set_index++) {
            Set<Integer> set = partition_iter.next();
            set_permutations[set_index] = 
                new TiedAltPermutations(set, alternative_counter, ballot);
            alternative_counter += set.size();
        }

        if (alternative_counter != ballots.get_dimension()) {
            throw new IllegalArgumentException();
        }

        return set_permutations;
    }

    /** Compute the set of winning ballots. */
    private Set<Vector> generate_winning_ballots() {
        int[] ballot = new int[ballots.get_dimension()];
        Collection<Set<Integer>> partition = get_partition();
        TiedAltPermutations[] permutation_sets =
            generate_permutations(partition, ballot);

        Set<Vector> winning = new HashSet<Vector>();
        
        winning.add(new Vector(ballot));
        
        int set_to_advance = 0;
        while (set_to_advance < permutation_sets.length) {
            TiedAltPermutations permutation_set =
                permutation_sets[set_to_advance];
            // Have we used up all the permutations for this set of
            // alternatives?
            if (permutation_set.at_last_permutation()) {
                // Then go back to first permutation and start again after
                // advancing the alternatives set ranked above this one.
                permutation_set.goto_first_permutation();
                set_to_advance++;
            } else {
                // Advance this set and record the resulting ballot
                permutation_set.goto_next_permutation();
                winning.add(new Vector(ballot));
                set_to_advance = 0;
            }
        }

        return Collections.unmodifiableSet(winning);
    }

    /** 
     * Get all the ballots that are "winning ballots" according to the center.
     */
    public Set<Vector> get_winning_ballots() {
        if (winning_ballots == null && !center.is_nav()) {
            winning_ballots = generate_winning_ballots();
        }

        return winning_ballots;
    }

    /** Generate a string description of this outcome. */
    private String generate_description() {
        if (center.is_nav()) {
            return "undefined";
        }

        StringBuilder desc = new StringBuilder(ballots.get_dimension()*2);
        Iterator<Set<Integer>> partition_iter = get_partition().iterator();

        while (partition_iter.hasNext()) {
            if (desc.length() != 0) {
                desc.insert(0, ">");
            }

            Set<Integer> set = partition_iter.next();
            if (set.size() > 1) {
                desc.insert(0, "]");
            }
            Iterator<Integer> set_iter = set.iterator();
            while (set_iter.hasNext()) {
                desc.insert(0, ballots.alternative_name(
                            set_iter.next().intValue()));
            }
            if (set.size() > 1) {
                desc.insert(0, "[");
            }
        }

        return desc.toString();
    }

    /** Get a string description of this outcome. */
    public String toString() {
        if (description == null) {
            description = generate_description();
        }

        return description;
    }
}

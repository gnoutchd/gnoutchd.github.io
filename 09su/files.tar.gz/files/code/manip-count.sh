#!/bin/sh

for alts in 3 4 ; do
	for voters in 3 4 5 6 ; do
		echo $voters `manip-count.awk < ${alts}_${voters}.manip.txt`
	done
	echo
	echo
done

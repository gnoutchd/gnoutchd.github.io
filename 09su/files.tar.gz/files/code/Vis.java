// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.io.PrintStream;

/** Output HTML code to visualize the profile given in command-line arguments in
 * the demo program. */
public class Vis {

    private static final String header = 
"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"\n" + 
"    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n" + 
"<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\" xml:lang=\"en-US\">\n" + 
"<head>\n" + 
"<base href=\"file:///home/gnoutchd/College/09cSU/demo/\">\n" + 
"<script src=\"wz_jsgraphics.js\"></script>\n" + 
"<script src=\"jsMedian.js\"></script>\n" + 
"<script src=\"voting-rules.js\"></script>\n" + 
"<link rel=\"stylesheet\" type=\"text/css\" href=\"jsMedian.css\">\n" + 
"</head>\n" + 
"<body>\n" + 
"\n" + 
"<center>\n" + 
"<script>\n" + 
"var sim = new jsMedian.Simulation({\n" + 
"  width: 625,\n" + 
"  height: 512,\n" + 
"  points: ' \\"; 

    private static final String footer =
"',\n" +
"  position: '(310, 258)',\n" +
"  allowNewPoints: 0,\n" +
"  allowTransformations: 0,\n" +
"  fixInitialPoints: 1,\n" +
"  pointSize: 11,\n" +
"  MAXWEIGHT: 20,\n" +
"  SHORTESTFUZZ: 3,\n" +
"  helpFile: \"voting-rules-help.html\",\n" +
"  showShortest: 1,\n" +
"  model: \"Mediancentre\",\n" +
"  showDrawer: 1,\n" +
"  showDrawerPull: 0\n" +
"});\n" +
"</script>\n" +
"\n" +
"</center>\n" +
"</body>\n" +
"</html>";

    /** Project the given 3-vector onto the 2-d plane given by x + y + z = n */
    private static Vector project(Vector orig) {
        final double sqrt_6 = Math.sqrt(6);
        final double sqrt_2 = Math.sqrt(2);
        return new Vector(
                -orig.getComp(0)/sqrt_6 + 2*orig.getComp(1)/sqrt_6 - 
                    orig.getComp(2)/sqrt_6,
                orig.getComp(0)/sqrt_2 - orig.getComp(2)/sqrt_2);
    }

    public static void main(String[] args) {
        PrintStream out;
        try {
            out = new PrintStream("vis.html");
        } catch (Exception e) {
            System.exit(255);
            return;
        }
        Vector[] hex = {
            new Vector(-2, 0, 2),
            new Vector(0, -2, 2),
            new Vector(2, -2, 0),
            new Vector(2, 0, -2),
            new Vector(0, 2, -2),
            new Vector(-2, 2, 0)};
        Vector center = new Vector(310, 258);
        final double multiplier = 75.0;
        final double label_ext = .15;
        Vector label_offset = new Vector(-25, 0);
        Ballots ballots = new Ballots(3);

        out.println(header);
        for (int i = 0; i < hex.length; i++) {
            Vector loc_raw = project(hex[i]).mult(multiplier);
            Vector label = loc_raw.mult(label_ext).add(label_offset);
            Vector loc = loc_raw.add(center);

            out.println("   " + args[ballots.get_index_of(hex[i])] +
                    " @ (" + (int)loc.getComp(0) + ", " + (int)loc.getComp(1) + ") = \"" +
                    ballots.toString(hex[i]) + "\" @ (" +
                    (int)label.getComp(0) + ", " + (int)label.getComp(1) +") \\");
        }
        out.println(footer);
    }
}

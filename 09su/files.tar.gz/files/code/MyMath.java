// vim: tabstop=4 shiftwidth=4 cindent
// Custom mathematical functions
// First version: Ari Morse, Summer 2007
// Extended by Daniel Gnoutcheff, Summer 2009

import java.math.BigInteger;
import java.util.Arrays;

public class MyMath 
{
	public static int factorial(int n) {
		
		if (n == 1)
			return n;
		else
			return n*factorial(n-1);
	}

	/** Return the factorial of n, using unlimited precision */
	public static BigInteger factorial_big(BigInteger n) {
		if (n.equals(BigInteger.ONE)) {
			return n;
		} else {
			return n.multiply(factorial_big(n.subtract(BigInteger.ONE)));
		}
	}

	/** Return the value of "n choose p" */
	public static BigInteger choose_big(BigInteger n, BigInteger p) {
		return factorial_big(n).divide(
					factorial_big(p) .multiply( factorial_big(n.subtract(p)))
				);
	}

	/** Return the lowest integer not less than n/m */
	public static int divRoundUp(int n, int m) {
		return (int)Math.ceil((double)n / m);
	}

	public static double roundTo(double value, int precision) {
        double multiply = Math.pow(10, precision);
        return Math.ceil(value*multiply)/multiply;
    }
	
	/** Swap the elements at the given indexes in the given integer array. A
	 * helper function for permute().
	 */
	private static void swap(int[] array, int i, int j) {
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

	/** Generate all the permutations of the given integers, in a predictable
	 * order. */
	public static int[][] permute(int[] elements) {
		int[][] permu = new int[factorial(elements.length)][];
		int[] ref = elements.clone();
		Arrays.sort(ref);
		int[] subindex = new int[elements.length - 1];
		
		for (int slot = 0; slot < subindex.length; slot++) {
			subindex[slot] = slot;
		}
		
		permu[0] = ref.clone();
		for (int p = 1; p < permu.length; p++) {
			int slot = ref.length - 2;
			while (subindex[slot] == ref.length - 1) {
				int tmp = ref[slot];
				for (int i = slot; i < ref.length - 1; i++) {
					ref[i] = ref[i+1];
				}
				ref[ref.length - 1] = tmp;
				subindex[slot] = slot;
				slot--;
			}

			subindex[slot]++;
			swap(ref, slot, subindex[slot]);

			permu[p] = ref.clone();
		}

		return permu;
	}

	/** Find the index of the given permutation of the given elements as
	 * determined by permute(). This function describes the order of the
	 * permutations returned by permute(). It is used by
	 * MedianRule.get_garrisoned_index().
	 */
	public static int permute_index_of(int[] permutation, int[] elements) {
		int[] ref = elements.clone();
		Arrays.sort(ref);

        int[] factorials = new int[permutation.length - 1];
        factorials[0] = 1;
        for (int i = 1; i < factorials.length; i++) {
            factorials[i] = factorials[i-1] * (i + 1);
        }

        int index = 0;
        for (int c = 0; c < permutation.length - 1; c++) {
            int subindex = Arrays.binarySearch(ref, permutation[c]);
            for (int pc = 0; pc < c; pc++) {
                if (permutation[pc] < permutation[c]) {
                    subindex--;
                }
            }

            index += factorials[permutation.length - 2 - c] * subindex;
        }

        return index;
	} 

    /**
     * Convert an Integer[] to an int[]
     */
    public static int[] to_primitive(Integer[] to_cast) {
        int[] to_return = new int[to_cast.length];
        for (int i = 0; i < to_cast.length; i++) {
            to_return[i] = to_cast[i].intValue();
        }
        return to_return;
    }
}

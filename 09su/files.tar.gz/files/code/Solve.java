// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.util.List;
import java.util.ArrayList;

/** Finds the mediancentre and outcome of the profile given in command-line
 * arguments, optionally starting the descent at the given location, and dumps
 * the descent path followed. */
public class Solve {
    public static void main(String[] args) {
        int arg_index = 0;
        
        // Read in the profile
        List<Integer> profile_list = new ArrayList<Integer>();
        boolean profile_end_reached = false;
        while (arg_index < args.length && !profile_end_reached) {
            try {
                profile_list.add(Integer.parseInt(args[arg_index]));
                arg_index++;
            } catch (NumberFormatException e) {
                profile_end_reached = true;
            }
        }

        if (profile_list.size() == 0) {
            System.err.println("No profile given!");
            return;
        }

        // Find the number of alternatives this profile is for, bail it it
        // doesn't make sense.
        int num_alternatives = 1;
        int factors_uncanceled = profile_list.size();
        while (factors_uncanceled != 1) {
            num_alternatives++;
            if (factors_uncanceled % num_alternatives != 0) {
                System.err.println("Invalid profile length.");
                return;
            }
            factors_uncanceled /= num_alternatives;
        }

        // Initialize the ballot list and the profile analyzer.
        Ballots ballots = new Ballots(num_alternatives);
        int[] profile = MyMath.to_primitive(
                profile_list.toArray(new Integer[0]));
        ProfileAnalyzer analyzer = new ProfileAnalyzer(profile, ballots);

        // Parse the starting point/ballot, if given
        int starting_ballot_index = -1;
        Vector starting_point = null;
        if (arg_index < args.length) {
            String start_spec_type = args[arg_index];
            arg_index++;
            if (start_spec_type.equals("start")) {
                // Starting point specified as a location
                double start_comps[] = new double[num_alternatives];
                for (int c = 0; c < num_alternatives; c++) {
                    if (arg_index >= args.length) {
                        System.err.println(
                                "Two few components in starting point.");
                        return;
                    }

                    String component = args[arg_index];
                    try {
                        start_comps[c] = Integer.parseInt(component);
                        c++;
                        arg_index++;
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid start-point component " +
                                component);
                        return;
                    }
                }
                starting_point = new Vector(start_comps);
            } else if (start_spec_type.equals("start-ballot")) {
                // Staring point specified as a vertex (i.e. a ballot)
                if (arg_index >= args.length) {
                    System.err.println("No ballot specified!");
                    return;
                }
                String index_str = args[arg_index];
                arg_index++;

                try {
                    starting_ballot_index = Integer.parseInt(index_str);
                    if (starting_ballot_index < 0 || 
                            starting_ballot_index >= ballots.num_ballots()) {
                        System.err.println("Ballot index " +
                                starting_ballot_index + " out of range.");
                        return;
                    }
                    starting_point = ballots.get(starting_ballot_index);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid ballot index " + index_str);
                    return;
                }
            } else {
                System.err.println("Unreconized argument " + start_spec_type);
                return;
            }
        }

        if (arg_index < args.length) {
            System.err.println("Too many arguments.");
            return;
        }

        // Is it defined?
        analyzer.do_median_not_a_vector_check();
        if (analyzer.get_median_estimate() != null) {
            System.out.println("Median undefined.");
            return;
        }

        // At a vertex?
        analyzer.do_vertex_check();
        if (analyzer.get_median_estimate() != null) {
            System.out.println("At vertex.");
        } else {
            // Not at vertex. Run the descent algorithm
            if (starting_point != null) {
                System.out.print("Starting at " + starting_point);
                if (starting_ballot_index != -1) {
                    System.out.print(" (ballot " + 
                            ballots.toString(starting_point) + ")");
                }
                System.out.println();

                analyzer.set_median_estimate(starting_point);
            } else {
                Vector mean = analyzer.get_mean();
                analyzer.set_median_estimate(mean);
                System.out.println("Starting at " + mean + " (mean).");
            }

            while (analyzer.descend()) {
                System.out.println("Descended to " +
                        analyzer.get_median_estimate());
            }
        }

        Vector median = analyzer.get_median_estimate();
        OutcomeAnalyzer outcome = new OutcomeAnalyzer(median, ballots);
        System.out.println("Median: " + median + " (" + outcome + ")");
    }
}


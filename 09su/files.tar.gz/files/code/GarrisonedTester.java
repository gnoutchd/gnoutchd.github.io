// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80

// Daniel Gnoutcheff, Summer 2009

/** Test out get and get_index_of from MedianRule */
public class GarrisonedTester {
    public static void main(String[] args) {
        Ballots subject = new Ballots(Integer.parseInt(args[0]));

        for (int g = 0; g < subject.num_ballots(); g++) {
            Vector garrisoned = subject.get(g);
            int reverse = subject.get_index_of(garrisoned);
            System.out.print("Ballot " + g + ": " + garrisoned +
                    " [" + subject.toString(garrisoned) + "]" +
                    " (reverse: " + reverse + ")");
            if (reverse != g) {
                System.out.println(" mismatch!");
                return;
            }
            System.out.println();
        }
    }
}

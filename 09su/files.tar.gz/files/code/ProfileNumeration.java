// vim: tabstop=4 shiftwidth=4 cindent textwidth=80
import java.io.*;
import java.math.BigInteger;

/**
 * ProfileNumeration: enumerate (and save) all possible profiles of an election
 * with a given number of alternatives and voters.
 */
// Started by Ari Morse
// Nearly rewritten by Daniel Gnoutcheff, Summer 2009
public class ProfileNumeration {
	/** The place to send our output */
	private Writer output;
	/** The number of profiles we expect to output. */
	private int expected;
	/** The number of profiles we have printed so far. */
	private int counter;
	/** The number of profiles to print before updating the progress display. */
	private int report_interval;

	/** Prepare to output a new set of profiles. */
	private void print_init(int num_expected, Writer out) {
		counter = 0;
		expected = num_expected;
		report_interval = MyMath.divRoundUp(num_expected, 100);
		output = out;
	}

	/** Output the given profile and report our progress to System.out.
	 * @param profile the profile to output
	 * @param output the place to print the profile to. Probably should not
	 * correspond to System.out, as that would cause the progress reporting to
	 * get mashed together with the real output.
	 */
	private void print_profile(int[] profile) throws IOException {
		for(int l = 0; l < profile.length; l++)
			output.write(profile[l] + " ");
		output.write('\n');

		counter++;
		if (counter % report_interval == 0) {
			int percent_done = (int)(((double)counter / expected) * 100.0);
			System.err.printf("%3d%% done.\r", percent_done);
		}
	}

	/** We have completed output of this set of profiles. Print appropriate
	 * messages and warnings to System.out. */
	private void print_finish() {
		if (counter >= report_interval) {
			System.err.println("100% done.");
		}
		System.err.println(counter + " profiles counted.");
		if (counter != expected) {
			System.err.println("Warning: " + expected + " expected.");
		}
	}

	/**
	 * Enumerate all possible profiles with the given number of voters with a
	 * prefix formed from the first 'prefix' elements in 'profile[]'. Print the
	 * generated profiles to 'out'.
	 */
	private void enumerate(int profile[], int prefix, int num_voters)
	   		throws IOException {
		if (prefix == profile.length-1) {
			profile[prefix] = num_voters;
			print_profile(profile);
		} else {
			for (int i = num_voters; i >= 0; i--) {
				profile[prefix] = i;
				enumerate(profile, prefix+1, num_voters-i);
			}
		}
	}

	/** Print all possible election profiles with the given number of voters and
	 * given number of alternatives, printing into the given writer.
	 */
	public void print(int num_alternatives, int num_voters,
			Writer out) throws IOException {
		int num_ballots = MyMath.factorial(num_alternatives);

		BigInteger num_expected_big = MyMath.choose_big(
				BigInteger.valueOf(num_voters + num_ballots - 1), 
				BigInteger.valueOf(num_voters));
		if (num_expected_big.compareTo(BigInteger.valueOf(Integer.MAX_VALUE))
			   	> 0) {
			System.err.println("ERROR: too many profiles to enumerate (" +
					num_expected_big.toString() + ")");
			return;
		}
		int num_expected = num_expected_big.intValue();

		int profile[] = new int[num_ballots];

		print_init(num_expected, out);
		enumerate(profile, 0, num_voters);
		print_finish();
	}

	/** A simple way to use this class from the command line.
	 * Usage: java ProfileNumeration [num alternatives] [num voters]
	 * Prints profiles to a file named '[num alternatives]_[num voters].txt'
	 */
	public static void main(String[] args) {
		int alternatives = Integer.parseInt(args[0]);
		int voters = Integer.parseInt(args[1]);
		ProfileNumeration enumerator = new ProfileNumeration();

		try {
			BufferedWriter br = new BufferedWriter(
					new PrintWriter(alternatives+"_"+voters+".txt"));
			enumerator.print(alternatives, voters, br);
			br.close();
		} catch (IOException e) {
			System.err.println("IO error.");
		}
	}

}

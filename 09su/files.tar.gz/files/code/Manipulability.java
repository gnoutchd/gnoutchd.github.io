// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.PrintWriter;

/** Find manipulations under the mean and mediancentre rules. */
public class Manipulability implements ProfileSink {
    /** The ballot set we use. */
    private Ballots ballots;

    /** Create a new manipulations checker, prepared to process profiles for the
     * given number of alternatives. */
    public Manipulability(int alternatives) {
        ballots = new Ballots(alternatives);
    }

    /** Check if the given ballot/outcome pairs represent a manipulation. If so,
     * add a string describing the manipulation to the given list. */
    private void manipulation_check(int move_from, int move_to,
            OutcomeAnalyzer old_outcome, OutcomeAnalyzer new_outcome, 
            List<String> report_to) {

        int[] old_winners = old_outcome.get_winners();
        int[] new_winners = new_outcome.get_winners();

        if (old_winners == null || new_winners == null) {
            return;
        }

        int old_winner = old_winners[0];
        int new_winner = new_winners[0];
        Vector old_ballot = ballots.get(move_from);
        
        if (old_ballot.getComp(new_winner) > old_ballot.getComp(old_winner)) {
            // We have a manipulation. Record it.
            Vector new_ballot = ballots.get(move_to);
            String desc = ballots.toString(old_ballot) + " to " +
                ballots.toString(new_ballot) + ": gets " +
                ballots.alternative_name(new_winner) + " (" +
                new_outcome + ")";
            report_to.add(desc);
        }
    }

    /** Report the given set of manipulations for a rule with the given name. */
    private void report(String name, OutcomeAnalyzer original_outcome,
            List<String> manipulations, PrintWriter out) {
        if (original_outcome.get_center().is_nav()) {
            out.println(name + ": undefined");
            return;
        }

        int original_winner = (original_outcome.get_winners())[0];
        out.print(name + ": " + ballots.alternative_name(original_winner) +
                " (" + original_outcome + ").");

        if (manipulations == null || manipulations.size() == 0) {
            out.println();
        } else {
            out.println(" manipulable");

            Iterator<String> iter = manipulations.iterator();
            while (iter.hasNext()) {
                out.println("  " + iter.next());
            }
        }
    }

    /** Find and print out manipulations under the mean and mediancentre rules
     * of the given profile. Returns true if a manipulation was found. */
    public boolean process_profile(int[] profile, PrintWriter out) {
        ProfileAnalyzer base_profile = new ProfileAnalyzer(profile, ballots);
        base_profile.optimize_median_estimate();

        OutcomeAnalyzer base_mean =
            new OutcomeAnalyzer(base_profile.get_mean(), ballots);
        List<String> manip_mean = new ArrayList<String>();

        OutcomeAnalyzer base_median = 
            new OutcomeAnalyzer(base_profile.get_median_estimate(), ballots);
        List<String> manip_median = new ArrayList<String>();

        // For each possible vote change someone could make ...
        for (int move_from = 0; move_from < profile.length; move_from++) {
            if (profile[move_from] == 0) {
                continue;
            }
            profile[move_from]--;
            for (int move_to = (move_from + 1) % profile.length;
                    move_to != move_from;
                    move_to = (move_to + 1) % profile.length) {
                profile[move_to]++;

                ProfileAnalyzer new_profile
                    = new ProfileAnalyzer(profile, ballots);
                new_profile.optimize_median_estimate();

                OutcomeAnalyzer new_mean = new OutcomeAnalyzer(
                        new_profile.get_mean(), ballots);
                manipulation_check(move_from, move_to, base_mean, new_mean, 
                        manip_mean);

                OutcomeAnalyzer new_median = new OutcomeAnalyzer(
                        new_profile.get_median_estimate(), ballots);
                manipulation_check(move_from, move_to, base_median, new_median,
                        manip_median);

                profile[move_to]--;
            }
            profile[move_from]++;
        }

        // Print out the manipulations found
        report("Mean", base_mean, manip_mean, out);
        report("Median", base_median, manip_median, out);

        return (manip_mean.size() > 0 || manip_median.size() > 0);
    }


    /** Return the number of alternatives we can handle, as per the ProfileSink
     * interface. */
    public int num_alternatives() {
        return ballots.get_dimension();
    }

    /** A simple command-line interface. */
    public static void main(String[] args) {
        Manipulability manip = new Manipulability(Integer.parseInt(args[0]));
        ProfileSource.stdio(manip);
    }
}

// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

/** Represents a double-precision floating-point number with an error term. Two
 * numbers are considered to be equal if the inverals created by the value and
 * the error term overlap. */
// Intended for MedianRule to help find the winning ballot(s).
public class Estimate implements Comparable<Estimate> {
    /** The estimate. */
    public final double val;
    /** The error term. */
    public final double error;

    /** Create an estimate with the given value and error term. */
    public Estimate(double new_val, double new_error) {
        val = new_val;
        error = new_error;
    }

    /** Returns true iff the given estimate is equivalent to this one (i.e if
     * the error bars match). */
    public boolean equals(Object other) {
        return (other instanceof Estimate) &&
           (compareTo((Estimate)other) == 0);
    }

    /** Compare the given double to this one, considering them equal if the
     * error bars overlap. */
    public int compareTo(Estimate other) {
        if ( other.val + other.error > this.val - this.error &&
             other.val - other.error < this.val + this.error) {
            return 0;
        } else if (this.val < other.val) {
            return -1;
        } else {
            return 1;
        }
    }
}

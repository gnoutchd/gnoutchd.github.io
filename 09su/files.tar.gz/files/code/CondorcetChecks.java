// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.io.PrintWriter;
import java.util.Arrays;

/** Helps determine the Condorcet efficiency of the mean and median rules.
 * Provides a command-line interface for doing this. */
public class CondorcetChecks implements ProfileSink {
    /** Ballot set to use */
    private Ballots ballots;

    /** Setup a new condorcet winner checker */
    public CondorcetChecks(int num_alternatives) {
        ballots = new Ballots(num_alternatives);
    }

    /** Calculate Net(alt1 &gt; alt2) according to the given profile. */
    private int net_pairwise_majority(int alt1, int alt2, int[] profile) {
        int net = 0;

        for (int b = 0; b < profile.length; b++) {
            if (profile[b] > 0) {
                Vector ballot = ballots.get(b);
                if (ballot.getComp(alt1) > ballot.getComp(alt2)) {
                    net += profile[b];
                } else {
                    net -= profile[b];
                }
            }
        }

        return net;
    }

    /** Return the ID number of the alternative that is the Condorcet winner by
     * the given profile, or -1 if there is none. */
    private int condorcet_winner(int[] profile) {
        // We assume that everyone's the Condorcet winner, and then we
        // pit every candidate against each other in 1-on-1 contests and knock
        // out all the candidates that can't be the Condorcet winner.
        int num_alt = ballots.get_dimension();
        boolean alt_is_condorcet[] = new boolean[num_alt];
        for (int i = 0; i < num_alt; i++) {
            alt_is_condorcet[i] = true;
        }
        int num_condorcet = num_alt;

        // For each possible pair of alternatives (not caring about order)
        int alt1 = 0;
        while (alt1 < num_alt && num_condorcet > 0) {
            int alt2 = alt1 + 1;
            while (alt2 < num_alt & num_condorcet > 0) {
                // Find Net(alt1 > alt2)
                int net = net_pairwise_majority(alt1, alt2, profile);

                // If this result proves that one or both of alt1 and alt2
                // cannot be the sole Condorcet winner, record that fact.
                if (net <= 0 && alt_is_condorcet[alt1]) {
                    alt_is_condorcet[alt1] = false;
                    num_condorcet--;
                }
                if (net >= 0 && alt_is_condorcet[alt2]) {
                    alt_is_condorcet[alt2] = false;
                    num_condorcet--;
                }

                alt2++;
            }

            // If alt1 is not the Condorcet winner, we would have proved that by
            // now.
            if (alt_is_condorcet[alt1]) {
                return alt1;
            }

            alt1++;
        }

        // No Condorcet winner found
        return -1;
    }

    /** Report if the outcome from the rule of the given name is consistent with
     * the given Condorcet winner. */
    private void report(String name, OutcomeAnalyzer outcome, int condorcet,
            PrintWriter out) {

        out.print(name + ": " + outcome);
        int[] winners = outcome.get_winners();
        if (condorcet >= 0) {
            if (winners == null || winners.length != 1 || 
                    winners[0] != condorcet) {
                out.print(" (mismatch)");
            } else {
                out.print(" (match)");
            }
        }
        out.println();
    }

    /** Check whether the mean and median rule select the Condorcet winner (if
     * it exists) and record this profile in the Condorcet efficiency stats. */
    public boolean process_profile(int[] profile, PrintWriter out) {
        int condorcet_winner = condorcet_winner(profile);
        out.print("Condorect winner: ");
        if (condorcet_winner >= 0) {
            out.println(ballots.alternative_name(condorcet_winner));

            ProfileAnalyzer analyzer = new ProfileAnalyzer(profile, ballots);

            OutcomeAnalyzer mean = 
                new OutcomeAnalyzer(analyzer.get_mean(), ballots);
            report("Mean", mean, condorcet_winner, out);

            analyzer.optimize_median_estimate();
            OutcomeAnalyzer median = 
                new OutcomeAnalyzer(analyzer.get_median_estimate(), ballots);
            report("Median", median, condorcet_winner, out);
        } else {
            out.println("undefined");
        }

        return false;
    }

    /** Report the number of alternatives we are ready to handle, as per the
     * ProfileSink interface. */
    public int num_alternatives() {
        return ballots.get_dimension();
    }

    public static void main(String[] args) {
        CondorcetChecks checker = new
            CondorcetChecks(Integer.parseInt(args[0]));
        ProfileSource.stdio(checker);
    }
}

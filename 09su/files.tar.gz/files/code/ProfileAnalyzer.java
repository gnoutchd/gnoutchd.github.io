// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80

// Daniel Gnoutcheff, Summer 2009
// Based on FindMedianCentre.java by Ari Morse and Andy Mackenzie

/** Represents a certain profile (given at instantiation) and an estimate as to
 * what the mediancentre is under that profile. Allows for detailed analysis of
 * a certain profile with respect to the mean and mediancentre.
 *
 * <p>People interested only in what the mediancentre is (and not in the mean,
 * the descent path used, etc.) will want to use the static find_median()
 * method. See also utility methods in the Outcome class.
 */
public class ProfileAnalyzer {
    /** The profile under analysis */
    private int[] profile;
    /** The set of ballots used to interpret the profile. */
    private Ballots ballots;
    /** The mean under the current profile. Null if not yet calculated.
     * Sometimes used as an initial estimate and for comparison. */
    private Vector mean;
    /** The current mediancentre estimate. Null if no estimate is set. If the
     * mediancentre is known to be nonexistent, this is set to Vector.NaV */
    private Vector median_est;
    /** The "force" applied to a ring at the location of the current
     * mediancentre estimate, under the pulley model of the mediancentre.
     * (Usually equivalent to the gradient.) Null if not yet calculated. Not
     * valid if the median estimate is not set of is set to Vector.Nav. */
    private Vector force;
    /** The sum of distances from the current mediancentre estimate to all the
     * weighted vertexes. -1 if this has not yet been calculated. Not valid if
     * the mediancentre estimate is not set. */
    private double sum_of_dists;

    /** Create a new analyzer for the given profile, using the given ballot set
     * to interpret the profile. Note that the number of ballots must match the
     * length of the profile array. Otherwise, an exception is thrown. */
    public ProfileAnalyzer(int new_profile[], Ballots ballot_set) {
        if (new_profile.length != ballot_set.num_ballots()) {
            throw new IllegalArgumentException();
        }
        ballots = ballot_set;
        profile = new_profile.clone();
        mean = null;
        median_est = null;
        force = null;
        sum_of_dists = -1;
    }

    /** Return the current mediancentre estimate. Null is returned if no
     * estimate is set. */
    public Vector get_median_estimate() {
        return median_est;
    }

    /** Set the mediancentre estimate to the given vector. Null clears the
     * current estimate. */
    public void set_median_estimate(Vector new_est) {
        median_est = new_est;
        sum_of_dists = -1;
        force = null;
    }

    /** Get the sum-of-distances at the current mediancentre estimate.
     * Calculate it if it hasn't been already. Returns -1 if the mediancentre
     * estimate is set to "doesn't exist". Throws an IllegalStateException if no
     * estimate has been set. */
    public double get_sum_of_dists() {
        if (median_est == null) {
            throw new IllegalStateException();
        }
        if (sum_of_dists == -1.0 && ! median_est.is_nav()) {
            sum_of_dists = sum_of_dists_at(median_est);
        }

        return sum_of_dists;
    }

    /** Get the sum-of-distances from the given point. 'point' must not be a
     * "not a vector". */
    public double sum_of_dists_at(Vector point) {
        double sum = 0.0;
        for (int i = 0; i < ballots.num_ballots(); i++) {
            sum += point.sub(ballots.get(i)).mag() * profile[i];
        }
        return sum;
    }

    /** Get the "force" applied to a ring at the current mediancentre estimate
     * under the "pulley model". Calculate it if it hasn't been already. Throws
     * an IllegalStateException if the median estimate is not set. */
    public Vector get_force() {
        if (median_est == null) {
            throw new IllegalStateException();
        }
        if (force == null) {
            force = force_at(median_est);
        }

        return force;
    }

    /** Determine the force on a ring at the given point.*/
    public Vector force_at(Vector point) {
        if (point.is_nav()) {
            return Vector.NaV;
        }

        Vector zero_vec = new Vector(ballots.get_dimension());

        // The force pulling us away from the current location
        Vector force_away = zero_vec;
        // The force keeping us at the current location (i.e. when at a vertex
        // with votes on it).
        int force_back_mag = 0;
        // The desired gradient is given by the sums of the normal vectors
        // pointing from each of the garrisoned votes toward the given point.
        for (int i = 0; i < ballots.num_ballots(); i++) {
            Vector curr_ballot = ballots.get(i);

            if (point.equals(curr_ballot)) {
                force_back_mag += profile[i];
            } else {
                force_away = force_away.add(
                        curr_ballot.sub(point).norm().mult(profile[i]));
            }

        }

        if (force_back_mag > force_away.mag()) {
            // The net force is zero
            return zero_vec;
        } else {
            Vector force = force_away;
            if (force_back_mag != 0) {
                Vector force_back = force.norm().mult(-force_back_mag);
                force = force.add(force_back);
            }
            return force;
        }
    }

    /** Get the mean under this profile. Calculate it if it hasn't been already.
     * */
    public Vector get_mean() {
        if (mean == null) {
            int num_points = 0;
            for (int i = 0; i < profile.length; i++) {
                num_points += profile[i];
            }

            double[] result = new double[ballots.get_dimension()];
            for (int j = 0; j < result.length; j++) {
                double sum = 0;
                for (int k = 0; k < ballots.num_ballots(); k++) {
                    sum += ballots.get(k).getComp(j)*profile[k];
                }
                result[j] = sum/num_points;
            }

            mean = new Vector(result);
        }

        return mean;
    }

    /** Return true if the profile under analysis is one where all votes are
     * evenly split over two ballots. */
    private boolean is_evenly_split() {
        int position = 0;
        int first_nonzero;

        // Look for the first ballot with some votes on it. Stop if such a thing
        // doesn't exist.
        while (position < profile.length && profile[position] == 0) {
            position++;
        }
        if (position == profile.length) {
            return false;
        }
        first_nonzero = profile[position];

        // Look for the next ballot with votes on it, and ensure that it has the
        // same number of votes as does the first nonzero ballot.
        position++;
        while (position < profile.length && profile[position] == 0) {
            position++;
        }
        if (position == profile.length 
                || profile[position] != first_nonzero) {
            return false;
        }

        // Ensure that the remaining ballots are zero
        position++;
        while (position < profile.length) {
            if (profile[position] != 0) {
                return false;
            }
            position++;
        }

        return true;
    }

    /**
     * Determines if the median is defined for this profile, setting the median
     * estimate to "not a vector" if it's not. Otherwise, leave the estimate
     * unchanged.
     */ 
    public void do_median_not_a_vector_check() {
        // In this case, we are dealing with points on a polyhedron, so it is
        // sufficient to ensure that we are not dealing with a profile where all
        // voters are evenly split between between two ballots. Note that this
        // test is *not* sufficient in the general case.
        if (is_evenly_split()) {
            set_median_estimate(Vector.NaV);
        }
    }

    /**
     * Return true iff the mediancentre is at the vertex that corresponds to the
     * ballot specified by the given index.
     */
    private boolean median_at_loc(int ballot) {
        return (force_at(ballots.get(ballot)).mag() == 0);
    }

    /** Check if the mediancentre is at one of the vertexes; if so, set the
     * mediancentre estimate to that. Otherwise, leave the estimate unchanged.*/
    public void do_vertex_check() {
        // NOTE: contrary to what Mackenzie's paper may suggest, it is *not*
        // sufficient to only check if one ballot has more than half the ballots
        // on it. The mediancentre's way trickier than that.
        for (int v = 0; v < ballots.num_ballots(); v++) {
            if (profile[v] > 0 && median_at_loc(v)) {
                set_median_estimate(ballots.get(v));
                return;
            }
        }
    }

    /** Using the pulley model, try to improve the mediancentre estimate (i.e.
     * reduce sum_of_dists). Returns true iff we actually did make an
     * improvement. Throws an IllegalStateException if the median estimate is
     * not set or is set to "not a vector". */
    public boolean descend() {
        Vector initial_median = get_median_estimate();
        if (initial_median == null || initial_median.is_nav()) {
            throw new IllegalStateException();
        }

        Vector initial_force = get_force();

        // Don't bother if the force is too small
        final double MIN_FORCE_MAG = Math.pow(10, -15);
        if (initial_force.mag() < MIN_FORCE_MAG) {
            return false;
        }

        double multiplier = 1.0;
        Vector new_median = initial_median.add(initial_force.mult(multiplier));
        double new_sum = sum_of_dists_at(new_median);

        // We may be able to do better by using smaller multipliers.
        int tries = 0;
        final int MAX_TRIES = 50;
        boolean try_again = true;
        while (try_again && tries < MAX_TRIES) {
            // See what median estimate and sum-of-distances we get when the
            // multiplier is halved.
            double proposed_multi = multiplier/2;
            Vector proposed_median = initial_median.add(
                    initial_force.mult(proposed_multi));
            double proposed_sum = sum_of_dists_at(proposed_median);

            // Did we do better?
            if (proposed_sum < new_sum) {
                multiplier = proposed_multi;
                new_median = proposed_median;
                new_sum = proposed_sum;
            } else {
                // Since the sum-of-distances function is convex, further
                // decreasing the multiplier would further increase the
                // sum-of-distances. Don't bother trying again.
                try_again = false;
            }

            tries++;
        }
        // Is the new mediancentre estimate actually better than the current
        // one?
        if (new_sum < get_sum_of_dists()) {
            set_median_estimate(new_median);
            sum_of_dists = new_sum;
            return true;
        } else {
            return false;
        }
    }

    /** Find the mediancentre to the best of our ability and set it as our
     * mediancentre estimate. */
    public void optimize_median_estimate() {
        set_median_estimate(null);

        do_median_not_a_vector_check();
        if (get_median_estimate() != null) {
            return;
        }

        do_vertex_check();
        if (get_median_estimate() != null) {
            return;
        }

        set_median_estimate(get_mean());
        boolean descent_successful;
        do {
            descent_successful = descend();
        } while (descent_successful);
    }  

    /** Return the mediancentre that results from solving the given election
     * profile. A convenience function to avoid using Analyzer directly. */
    public static Vector find_median(int[] profile, Ballots ballots) {
        ProfileAnalyzer analyzer = new ProfileAnalyzer(profile, ballots);
        analyzer.optimize_median_estimate();
        return analyzer.get_median_estimate();
    }
}

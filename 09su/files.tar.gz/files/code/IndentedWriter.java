// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009 

import java.io.Writer;
import java.io.FilterWriter;
import java.io.IOException;

/** Character-stream filter that indents text. */
public class IndentedWriter extends FilterWriter {
    private static final char[] indent = "  ".toCharArray();
    private boolean on_new_line;

    public IndentedWriter(Writer out) {
        super(out);
        on_new_line = true;
    }

    public void write(char[] buffer, int offset, int length) 
    throws IOException {
        int index = offset;
        int end = offset + length;
        while (index < end) {
            // Print newline(s), record the fact that we're on a new line
            int start = index;
            while (index < end && buffer[index] == '\n') {
                index++;
            }
            if (index > start) {
                super.write(buffer, start, index);
                on_new_line = true;
            }

            // Print non-newlines preceeded with indenting if on a new line,
            // mark the fact that we're not on a new line.
            start = index;
            while (index < end && buffer[index] != '\n') {
                index++;
            }
            if (index > start) {
                if (on_new_line) {
                    super.write(indent, 0, indent.length);
                }
                super.write(buffer, start, index);
                on_new_line = false;
            }
        }

    }

    public void write(char c) throws IOException {
        write(new char[] {c}, 0, 1);
    }

    public void write(String str, int off, int len) throws IOException {
        write (str.toCharArray(), 0, str.length());
    }

}

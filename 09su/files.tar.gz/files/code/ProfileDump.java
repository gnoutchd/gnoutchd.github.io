// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.io.PrintWriter;

/** Dump some random info about a profile. */
public class ProfileDump implements ProfileSink {
    Ballots ballots;

    public ProfileDump(int alternatives) {
        ballots = new Ballots(alternatives);
    }

    public int num_alternatives() {
        return ballots.get_dimension();
    }

    public boolean process_profile(int[] profile, PrintWriter out) {
        ProfileAnalyzer analyzer = new ProfileAnalyzer(profile, ballots);

        Vector mean = analyzer.get_mean();
        OutcomeAnalyzer mean_outcome = new OutcomeAnalyzer(mean, ballots);
        
        analyzer.optimize_median_estimate();
        Vector median = analyzer.get_median_estimate();
        OutcomeAnalyzer median_outcome = new OutcomeAnalyzer(median, ballots);

        out.println("Mean: " + mean + " (" + mean_outcome + ")");
        out.println("Median: " + median + " (" + median_outcome + ")");

        return false; // No issues to report
    }

    public static void main(String[] args) {
        ProfileDump dump = new ProfileDump(Integer.parseInt(args[0]));
        ProfileSource.stdio(dump);
    }
}

// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

/** Perform a few tests to check for certain kinds of symmetries that are known
 * to generate ties in the three-alternative case. */
public class SymCheck {
    /** The set of ballots being used, used to interpret the profiles we get. */
    private Ballots ballots;
    /** The indexes of the ballots ordered in a cycle around the hexagon (the
     * permutohedron on which all three-alternative ballots lie). */
    private int[] cycle;

    /** Setup the cycle. Do so in a way that is totally resistant to changes in
     * profile order (i.e. changes in Ballots). */
    private int[] generate_cycle() {
        int[][] rank_cycle = {
            {2, 1, 0},
            {2, 0, 1},
            {1, 0, 2},
            {0, 1, 2},
            {0, 2, 1},
            {1, 2, 0}
        };

        int[] index_cycle = new int[rank_cycle.length];
        for (int i = 0; i < rank_cycle.length; i++) {
            int[] garrisoned = new int[3];
            for (int c = 0; c < garrisoned.length; c++) {
                garrisoned[c] = ballots.get_rank(rank_cycle[i][c]);
            }
            index_cycle[i] = ballots.get_index_of(new Vector(garrisoned));
        }

        return index_cycle;
    }

    /** Prepare to perform symmetry checks on profiles interpreted according to
     * the given ballot set. */
    public SymCheck(Ballots ballot_set) {
        ballots = ballot_set;
        cycle = generate_cycle();
    }

    private int cycle(int i) {
        i %= cycle.length;
        if (i < 0) {
            i += cycle.length;
        }
        return cycle[i];
    }

    private void sub_line_ties(int[] profile) {
        for (int b = 0; b < 3; b++) {
            int first = cycle(b);
            int opposite = cycle(b+3);
            int to_subtract = Math.max(profile[first], profile[opposite]);
            profile[first] -= to_subtract;
            profile[opposite] -= to_subtract;
        }
    }

    private void sub_radial_ties(int[] profile) {
        for (int b = 0; b < 2; b++) {
            int first = cycle(b);
            int second = cycle(b+2);
            int third = cycle(b+4);
            
            int to_subtract = Math.max(profile[first], profile[second]);
            to_subtract = Math.max(to_subtract, profile[third]);

            profile[first] -= to_subtract;
            profile[second] -= to_subtract;
            profile[third] -= to_subtract;
        }
    }

    private int sum(int[] profile) {
        int sum = 0;
        for (int i = 0; i < profile.length; i++) {
            sum += profile[i];
        }
        return sum;
    }

    public Vector three_way_tie_check(int[] profile) {
        int[] copy = profile.clone();
        sub_line_ties(copy);
        sub_radial_ties(copy);

        if (sum(copy) == 0) {
            return new Vector(3);
        } else {
            return null;
        }
    }

    private Vector average(Vector v1, Vector v2) {
        double avg[] = new double[v1.numComp()];
        for (int c = 0; c < avg.length; c++) {
            avg[c] = (v1.getComp(c) + v2.getComp(c))/2;
        }
        return new Vector(avg);
    }

    /** Check for line symmetry, return the outcome if we find it. */
    public Vector line_sym_check(int[] profile) {
        // Check each of the tie-lines for symmetry
        int line = 0;
        boolean symmetry_found = false;
        while (!symmetry_found && line < 3) {
            // To have symmetry on this line, each pair of ballots must be
            // equal. Check that.
            int ballot_pair = 0;
            boolean violation_found = false;
            while (!violation_found && ballot_pair < 3) {
                int first_ballot = profile[cycle(line+ballot_pair-1)];
                int reflection = profile[cycle(line-ballot_pair-2)];
                if (first_ballot != reflection) {
                    violation_found = true;
                }
                ballot_pair++;
            }

            if (violation_found) {
                line++;
            } else {
                symmetry_found = true;
            }
        }

        if (symmetry_found) {
            if (profile[cycle(line-1)] == profile[cycle(line+1)]) {
                // It's a tie between all ballots, indicated by a zero-vector.
                return new Vector(3);
            } else {
                if (profile[cycle(line-1)] > profile[cycle(line+1)]) {
                    return average(
                            ballots.get(cycle(line-1)),
                            ballots.get(cycle(line-2)));
                } else {
                    return average(
                            ballots.get(cycle(line+1)),
                            ballots.get(cycle(line+2)));
                }
            }
        } else {
            return null;
        }
    }

    /** Check for "cross symmetry" */
    public Vector cross_sym_check(int[] profile) {
        for (int ballot = 0; ballot < cycle.length; ballot++) {
            if (  profile[cycle(ballot)] == profile[cycle(ballot+2)] &&
                profile[cycle(ballot+1)] == profile[cycle(ballot+3)] &&
                profile[cycle(ballot+4)] == 0 &&
                profile[cycle(ballot+5)] == 0) {
                return average(
                        ballots.get(cycle(ballot+1)),
                        ballots.get(cycle(ballot+2)));
            }
        }

        return null;
    }

    /** Check for both line symmetries and "cross symmetry". Return a vector
     * reflecting the outcome, if it is known from symmetry checks. If the
     * outcome is not known, return null. */
    // TODO: the code here could either look very clear or very stupid. Look
    // again with fresh eyes.
    public Vector check(int[] profile) {
        Vector outcome = null;

        outcome = three_way_tie_check(profile);
        if (outcome != null) {
            return outcome;
        }

        outcome = line_sym_check(profile);
        if (outcome != null) {
            return outcome;
        }

        outcome = cross_sym_check(profile);
        if (outcome != null) {
            return outcome;
        }

        return null;
    }
}

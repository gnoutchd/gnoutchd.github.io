// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

import java.io.PrintWriter;

/** Represents a class that takes profiles as input. */
public interface ProfileSink {
    /** Get the number of alternatives this sink expects profiles to be sized
     * for. */
    public int num_alternatives();

    /** Process a profile, printing any output data via the given PrintWriter.
     * Return true if there is something the user definitely should be
     * interested in.
     */
    public boolean process_profile(int[] profile, PrintWriter output);
}

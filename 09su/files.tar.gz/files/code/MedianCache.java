// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80

// Daniel Gnoutcheff, Summer 2009

import java.util.Arrays;

public class MedianCache {
    private MedianRule solver;
    private int[][] transforms;

    private Vector apply_reordering(Vector orig, int[] reordering) {
        double[] new_comps = new double[reordering.length];
        for (int c = 0; c < reordering.length; c++) {
            double value = orig.getComp(reordering[c]);
            new_comps[c] = value;
        }

        return new Vector(new_comps);
    }

    private int[] get_reordering(Vector orig, Vector goal) {
        int[] reordering = new int[orig.numComp()];

        for (int oc = 0; oc < reordering.length; oc++) {
            int gc = 0;
            while (orig.getComp(oc) != goal.getComp(gc)) {
                gc++;
            }
            reordering[gc] = oc;
        }

        return reordering;
    }

    private int[] generate_profile_transform(int[] point_transform,
        boolean negate) {
        int[] profile_transform = new int[solver.get_num_ballots()];


        for (int p = 0; p < profile_transform.length; p++) {
            Vector orig = solver.get_garrisoned(p);
            Vector transformed;
            
            transformed = apply_reordering(orig, point_transform);
            if (negate) {
                transformed = transformed.mult(-1);
            }

            profile_transform[p] = solver.get_garrisoned_index(transformed);
        }

        return profile_transform;
    }

    private int[][] generate_transforms() {
        int num_ballots = solver.get_num_ballots();
        Vector orig = solver.get_garrisoned(0);
        int[][] transforms = new int[num_ballots*2][];

        for (int t = 0; t < num_ballots; t++) {
            Vector goal = solver.get_garrisoned(t);
            int[] reordering = get_reordering(orig, goal);
            transforms[t*2] = generate_profile_transform(reordering, false);
            transforms[t*2 + 1] = generate_profile_transform(reordering, true);
        }

        return transforms;
    }

    public MedianCache(int num_alternatives) {
        solver = new MedianRule(num_alternatives);
        transforms = generate_transforms();
    }

    // Debugging/testing routine
    public static void main (String[] args) {
        MedianCache subject = new MedianCache(Integer.parseInt(args[0]));

        for (int i = 0; i < subject.transforms.length; i += 2) {
            System.out.println(Arrays.toString(subject.transforms[i]));
        }
    }

}

// vim: shiftwidth=4 softtabstop=4 expandtab cindent textwidth=80
// Daniel Gnoutcheff, Summer 2009

/** Represents the set of ballots for a number of alternatives fixed at
 * instantiation. Also represents the rank numbers used in those ballots. */
public class Ballots {
    /** The number of components in the ballots, which is equal to the number of
     * alternatives this instance supports */
    private int ballot_length;
    /** Rank numbers - the numbers associated with each position of the
     * preference ranking, in ascending order of preference. */
    private int[] ranks;
    /** Garrisoned ballots - the locations that represent each ballot. (See
     * Mackenzie's paper.) */
    private Vector[] ballots;

    /** Generate the rank numbers for the number of alternatives represented by
     * this instance. */
    private int[] make_ranks() {
        int[] new_ranks = new int[ballot_length];
        for (int r = 0; r < ballot_length; r++) {
            new_ranks[r] = 2*r - ballot_length + 1;
        }
        return new_ranks;
    }

    /** Generate all the garrisoned ballots. */
    private Vector[] make_ballots() {
        int ballots_raw[][] = MyMath.permute(ranks);
        
        Vector[] ballot_vecs = new Vector[ballots_raw.length];
        for (int i = 0; i < ballot_vecs.length; i++) {
            ballot_vecs[i] = new Vector(ballots_raw[i]);
        }

        return ballot_vecs;
    }

    /** Create a set of rank numbers and ballots for the given number of
     * alternatives. */
    public Ballots(int num_alternatives) {
        if (num_alternatives < 1) {
            throw new IllegalArgumentException("Must have at least one " +
                    "alternative.");
        }
        ballot_length = num_alternatives;
        ranks = make_ranks();
        ballots = make_ballots();
    }

    /** Get the number of components these ballots have. This is equivalent to
     * the number of alternatives represented. */
    public int get_dimension() {
        return ballot_length;
    }

    /** Get the number of ballots we have for this number of alternatives. */
    public int num_ballots() {
        return ballots.length;
    }

    /** Get the garrisoned ballot at the given index. */
    public Vector get(int i) {
        return ballots[i];
    }

    /** Get the index of the ballot represented by the given location. Returns
     * -1 if the given location is not a ballot, throws IllegalArgumentException
     * if the given vector is for the wrong number of alternatives. */
    // TODO: make this actually return -1 when required!
    public int get_index_of(Vector ballot) {
        if (ballot.numComp() != ballot_length) {
            throw new IllegalArgumentException("Expected " + ballot_length +
                    " components, got " + ballot.numComp());
        }

        int ballot_raw[] = new int[ballot_length];
        for (int c = 0; c < ballot_raw.length; c++) {
            ballot_raw[c] = (int)ballot.getComp(c);
        }

        return MyMath.permute_index_of(ballot_raw, ranks);
    }

    /** Get the rank number given to the alternative ranked 'i' positions above
     * the least favorite one. Zero, of course, refers to the least favorite. */
    public int get_rank(int i) {
        return ranks[i];
    }

    /** Give the name of the alternative at the given index */
    public char alternative_name(int id) {
        if (id < 0 && id > get_dimension()) {
            throw new IndexOutOfBoundsException();
        }

        return (char)('P' + id);
    }

    /** Return a String description of the given ballot. Behavior is undefined
     * if the given Vector is not actually a ballot. For non-ballots (e.g.
     * mediancentres), see OutcomeAnalyzer for a way to analyze the location. */
    // TODO: handle non-ballots robustly
    public String toString(Vector ballot) {
        char[] desc = new char[ballot.numComp()*2 - 1];

        for (int alternative = 0; alternative < ballot.numComp(); 
                alternative++) {
            char name = alternative_name(alternative);
            int ranking = 
                ((int)ballot.getComp(alternative) + ballot_length - 1)/2;
            desc[2*(ballot_length - ranking - 1)] = name;
        }

        for (int i = 1; i < desc.length; i += 2) {
            desc[i] = '>';
        }

        return String.valueOf(desc);
    }

}

// vim: tabstop=3 shiftwidth=3 cindent textwidth=80
// Started by Ari Morse
// Modified and documented by Daniel Gnoutcheff, Summer 2009

import java.util.Arrays;

/**
 * An immutable representation of an Euclidean vector. Vectors typically have a
 * number of double-precision components, but the can also be "undefined
 * vectors", a.k.a. "not a vector" (analogous to "NaN" floating-point numbers).
 * Not to be confused with the standard Java Vector class (the List
 * implementation)
 */
// TODO: Lots of methods throw IllegalArgumentExceptions when dimensions don't
// match between two vectors. Needs documentation, exception messages, perhaps a
// custom exception type?
// TODO: better norm() behavior for zero vectors?
public class Vector
{
	/** A standard "undefined" vector. */
	public static final Vector NaV = new Vector(0);

	/** The components of this vector. Null if this vector is "not a vector". */
	private double vec[];

   /**
    * Create a zero three-vector.
    */
   public Vector() {
      this(3);
   }

   /**
    * Create a zero vector of the specified dimension. If the specified
	 * dimension is less than '1', then this becomes an "undefined" vector.
    */
   public Vector(int dimension) {
		if (dimension > 0) {
			vec = new double[dimension];
		} else {
			vec = null;
		}
   }

   /**
    * Create a vector with components equal to those in the specified array.
    */
   public Vector(double ... new_vec) {
		if (new_vec == null) {
			vec = null;
		} else {
			vec = new_vec.clone();
		}
   }

	/**
	 * Create a vectors with components eqaul to those in the given integer
	 * array.
	 */
	public Vector(int[] new_vec) {
		vec = new double[new_vec.length];
		for (int i = 0; i < vec.length; i++) {
			vec[i] = new_vec[i];
		}
	}

	/**
	 * Returns true iff this vector is "undefined" (ie "not a vector").
	 */
	public boolean is_nav() {
		return (vec == null);
	}
	
   /**
    * Get the dimension of the space in which this Vector resides (aka the
    * number of components).
    */
   public int numComp() {
		if (vec == null) {
			return 0;
		} else {
			return vec.length;
		}
   }

   /**
    * Get the value of the component of the specified index
    */
   public double getComp(int component_number) {
      return vec[component_number];
   }

   /**
    * Set the specified component to the specified value. Only used internally
    * to setup new Vectors (add, mult, etc.).
    */
   private void setComp(int component_number, double new_value) {
      vec[component_number] = new_value;
   }
   
   /** Return a new vector equal to this one multiplied by the given scalar */
   public Vector mult(double x){
      int num_comp = numComp();
      Vector new_vec = new Vector(num_comp);
      for (int i = 0; i < num_comp; i++) {
         new_vec.setComp(i, getComp(i)*x);
      }
      return new_vec;
   }

   /** Return a new vector equal to the given one added to this one. */
   public Vector add(Vector other) {
      if (other == null) {
         return this;
      }

      int num_comp = numComp();
      if (other.numComp() != num_comp) {
         throw new IllegalArgumentException();
      }

      Vector new_vec = new Vector(num_comp);
      for (int i = 0; i < num_comp; i++) {
         new_vec.setComp(i, getComp(i) + other.getComp(i));
      }
      return new_vec;
   }
   
   /** Return a new vector equal to the given one subtracted from this one. */
   public Vector sub(Vector other) {
      if (other == null) {
         return this;
      }

      int num_comp = numComp();
      if (other.numComp() != num_comp) {
         throw new IllegalArgumentException();
      }

      Vector new_vec = new Vector(num_comp);
      for (int i = 0; i < num_comp; i++) {
         new_vec.setComp(i, getComp(i) - other.getComp(i));
      }
      return new_vec;
   }
   
   /** Compute the dot product of this vector and the given vector */
   public double dot(Vector other)
   {
      int num_comp = numComp();
      if (other == null || other.numComp() != num_comp) {
         throw new IllegalArgumentException();
      }

      double sum = 0.0;
      for (int i = 0; i < num_comp; i++) {
         sum += this.getComp(i) * other.getComp(i);
      }

      return sum;
   }

   /** Compute the magnitude of this vector */
   public double mag()
   {
      double mag_squared = 0.0;
      int num_comp = numComp();
      for (int i = 0; i < num_comp; i++) {
         mag_squared += Math.pow(getComp(i), 2);
      }

      return Math.sqrt(mag_squared);
   }

   /** 
    * Returns a unit (magnitude == 1) vector with the same direction as this
    * one.
    * Warning: this is undefined if this vector is the zero vector.
    */
   public Vector norm()
   {
      return mult(1 / mag());
   }
   
   /**
    * Returns true iff the given Vector is equivalent to this one.
    * WARNING: this is based on equality of floating-point numbers, which is
    * problematic. Don't use this!
    */
   public boolean equals(Object other) {
      if (! (other instanceof Vector)) {
           return false;
      }

      Vector other_vec = (Vector)other;
		return Arrays.equals(vec, other_vec.vec);
   }
  
   /** Return a string representation of this vector. */
   public String toString()
   {
      int num_comp = numComp();
      if (num_comp == 0) {
         return "";
      }

      String result = "<" + getComp(0);
      for (int i = 1; i < num_comp; i++) {
         result += ", " + getComp(i);
      }
		result += ">";

      return result;
   }

	/** A compliat implemenation of hashCode, so that Vectors are usable in Sets */
	public int hashCode() {
		return Arrays.hashCode(vec);
	}
}

#!/bin/sh
cd /home/gnoutchd/College/09cSU/presentaton
gvim -O demo*-notes -geometry 155x39-+0 &
firefox -fullscreen pres*.html &

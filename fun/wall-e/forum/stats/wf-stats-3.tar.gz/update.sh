#!/bin/bash

# Download and output a concise table describing all walleforum.com members

cookies-sql2txt ~/.mozilla/firefox/vkuuxfit.default/cookies.sqlite walleforum.com > walleforum-cookies.txt
curl="curl --cookie walleforum-cookies.txt --limit-rate 64K"

# Download all the member list pages, concatenate them, and send them to standard output
function mlist() {
	local mlist_base='http://walleforum.com/index.php?action=mlist;sort=registered;start='
	local mlist_step=30

	# Download and output (to stdout) the first page, and extract the 'start=' number of the last page
	# Within the backquotes, the output file descriptors used are:
	# /dev/fd/1 (stdout): number of the last page
	# /dev/fd/2 (stderr): curl's status messages
	# /def/fd/3: the first memberlist page, unprocessed
	{ local mlist_last=`$curl "${mlist_base}0" | sed -n '
		# Copy input
		w /dev/fd/3
		# Search for the last page number, stop searching once it we hit it
		1, \_<td>Pages: \[<b>1</b>\]_ {
			s_^.*<a class="navPages" href="'${mlist_base}'\([0-9]\+\)">[0-9]\+</a> </td>$_\1_p
		}'`
	} 3>&1
	
	# Download the remaining pages
	$curl "${mlist_base}[$mlist_step-$mlist_last:$mlist_step]"
}

# TODO: currently, we block (at xargs) until the entire memberlist is retrieved and parsed. Is this desirable? More parallelization might be achievable with curl's -K option.
mlist | grep --only-matching 'http://walleforum.com/index.php?action=profile;u=[0-9]\+' | xargs $curl | tee profiles.html | ./parse.sed

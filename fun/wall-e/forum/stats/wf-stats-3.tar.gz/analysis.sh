#!/bin/bash

source="$1"

echo '[b]Fastest posters[/b]'
./simplify.awk action=post-rate "$source" | sort -n -r | ./format.awk
echo

echo '[b]Highest power-level:[/b]'
./simplify.awk action=karma "$source" | sort -n -r | ./format.awk
echo

echo '[b]Highest power-level per post:[/b]'
./simplify.awk action=prod "$source" | sort -n -r | ./format.awk
echo

echo '[b]WALL•Eness rating (Level_Head style):[/b]'
./simplify.awk action=w-ness "$source" | sort -n -r | ./format.awk scale=yes

These files were created by Daniel Gnoutcheff <gnoutchd@union.edu> in the summer
of 2008 while working under the Union College summer research fellowship.

For background information, implementation notes, initial results, and a usage
tutorial, see Report/Report.pdf.

For information about each file in this directory:
 - Each *.pro file (i.e. IDL source file) contains comments describing its
   contents.
 - Each *.sav file (i.e. IDL binary "save" file) has a corresponding *.README or
   *_gen.pro file that contains a description of the contents of the save file.
   (Here, "gen" is short for "generate": the *_gen.pro files contain some of the
   IDL code that generated data in the corresponding save files.)

See also the DATA_STRUCTURES.README file, which contains a description of some
data structures that are used by multiple functions.

import java.util.Scanner;
// import java.io.File;
// import java.io.FileNotFoundException;

/**
 * Runnable program to test some park decision algorithim. 
 * @author Daniel Gnoutcheff
 *
 */
public class Driver {

	/**
	 * Read a cronological sequence of idle period lengths (in seconds) from
	 * standard input and run a simulation to see what a certan parking
	 * decision algorithim would do.
	 *   
	 * @param args command line arguments. First argument: the name of the file
	 * to read.
	 */
	public static void main(String[] args) {	
		final float PERIOD_MAX = 60*5;
		
		Parker subject = new Proposer4();
		
		/* Scanner data;
		try {
			data = new Scanner(new File(args[0]));
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("No file argument");
			return;
		} catch (FileNotFoundException e) {
			System.err.println("File \"" + args[0] + "\" not found");
			return;
		} */
		Scanner data = new Scanner(System.in);
		
		double timeWatched = 0.0;
		double timeParked = 0.0;
		int numParks = 0;
		
		float timeout = subject.getTimeout();
		while (data.hasNext()) {
			float periodLength = data.nextFloat();
			if (periodLength < PERIOD_MAX) {
				timeWatched += periodLength;
				if (periodLength > timeout) {
					numParks++;
					timeParked += periodLength - timeout;
				}
				subject.diskAccess(periodLength);
				timeout = subject.getTimeout();
			}
			
		}
		
		System.out.println("HD time observed: " + timeWatched + " seconds");
		System.out.println("Number of parks: " + numParks);
		System.out.println("Time parked: " + timeParked + " seconds");
		
		return;
	}

}

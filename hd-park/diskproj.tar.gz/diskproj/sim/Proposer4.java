/**
 * An implementation of my very simple "proposer" method.
 * @author Daniel Gnoutcheff
 *
 */
public class Proposer4 implements Parker {
	/**
	 * Minimum amount of time we want the disk to be parked at any given time.
	 */
	private final float MIN_PARKTIME = 30.0f;
	/**
	 * Amount of time (in seconds) we want to reserve for finding a good
	 * timeout.
	 */
	private final double COOK_TIME = 120.0;
	
	/**
	 * Timeout value we are currently using.
	 */
	private float timeoutCurrent = 6.0f;
	
	/**
	 * The possibly shorter timeout value we are "developing"
	 */
	
	private float timeoutProposed = 0.0f;
	/**
	 * Amount of time since the proposal was last "reset".
	 */
	private double proposalAge = 0.0;

	/**
	 * Update the proposed (and possibly current) timeout values based on this
	 * most recent disk access, as per the Parker specification.
	 */
	public void diskAccess(float period) {
		// Lengthen the proposed timeout, if desirable
		if (period > timeoutProposed &&
				period - timeoutProposed < MIN_PARKTIME) {
			timeoutProposed = period;
		}
		
		// If the proposal has been cooking for long enouth, make it current.
		proposalAge += period;
		if (proposalAge >= COOK_TIME) {
			timeoutCurrent = timeoutProposed;
			timeoutProposed = 0.0f;
			proposalAge = 0.0;
		} else if (period > timeoutCurrent &&
				period - timeoutCurrent < MIN_PARKTIME) {
			// The current timeout won't be replaced, but it's "known" to be
			// "bad". Extend it now.
			timeoutCurrent = period;
		}

	}

	/**
	 * Return the current timeout value, as per the Parker specification.
	 */
	public float getTimeout() {
		return timeoutCurrent;
	}

}

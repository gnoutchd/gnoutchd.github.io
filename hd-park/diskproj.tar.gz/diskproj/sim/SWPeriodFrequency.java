import sun.misc.Queue;

/**
 * A sliding-window type algorithim that assumes that the probability of a
 * certain idle period length is about equal to its frequency in the past n
 * idle period.
 *  
 * @author Daniel Gnoutcheff
 *
 */

/*
 * Version 1: original
 * When making a change, note what the original code was here.
 */

public class SWPeriodFrequency implements Parker {
	private final int TICS_PER_SEC = 2;
	private final float MAX_TIME = 10*60;
	private final float MIN_PARKTIME = 30.0f;
	private final int MIN_PARKTIME_TICKS = secsToTicks(MIN_PARKTIME);
	private final int NUM_PAST_EVENTS = 1000;
	
	/**
	 * A summary of the past NUM_PAST_EVENTS idle periods. Each element is
	 * defined to be:<br>
	 * <code>freqTable[time] = numSafePeriods(time) - 
	 *    numUnsafePeriods(time)</code><br>
	 * Where <code>time</code> is the current time, in ticks, 
	 * <code>numSafePeriods(time)<code> = the number of periods observed where
	 *   the disk says idle for the next <code>MIN_PARKTIME_TICKS</code> ticks
	 *   (i.e. where it is safe to park now),
	 * and <code>numUnsafePeriods(time)</code> = the number of periods observed
	 *    where the disk is accessed before MIN_PARKTIME_TICKS ticks (i.e.
	 *    where parking the disk is not safe.
	 * <p>In other words, if <code>freqTable[time]</code> is nonnegative, it's
	 *   safe to park.
	 */
	private int[] freqTable;
	
	/**
	 * A Queue of Integers, containing all of the previous idle period lengths
	 * (in ticks)
	 */
	// TODO: replace this with a faster primitive int-based queue
	private Queue pastEvents;
	
	/**
	 * The number of entries in the Queue. Should not exceed NUM_PAST_EVENTS
	 */
	/* TODO: replace this with a Queue that can tell us the number of elements
	 * it contains. */
	private int numPastEvents;
	
	/**
	 * Setup this implementation of the "SWPeriodFrequency" method
	 */
	public SWPeriodFrequency() {
		pastEvents = new Queue();
		freqTable = new int[secsToTicks(MAX_TIME)];
		for (int i = 0; i < freqTable.length; i++) {
			freqTable[i] = 0;
		}
		numPastEvents = 0;
	}
	
	/**
	 * Convert from seconds to ticks
	 */
	private int secsToTicks(float secs) {
		return (int)(secs * TICS_PER_SEC);
	}
	
	/**
	 * Convert from ticks to seconds
	 */
	private float ticksToSecs(int ticks) {
		return (float)ticks / TICS_PER_SEC;
	}

	/**
	 * Update the frequency table to add or remove a record of an idle period
	 * of the given length.
	 * 
	 * @param time the length of the idle period in question.
	 * @param delta number of entries to add (e.g. 1 to add one, -1 to remove
	 *   one)
	 */
	// TODO: combine additions and removals to same some time
	private void updateTable(int time, int delta) {
		// A park at 'time' is an case where it's unsafe to park in
		// [time, time - MIN_PARKTIME_TICKS] and safe to park in
		// [time - MIN_PARKTIME_TICKS - 1, 0]
		
		int i = Math.min(time, freqTable.length - 1);
		int maxParkSafe = time - MIN_PARKTIME_TICKS - 1;
		
		while (i > maxParkSafe && i >= 0) {
			freqTable[i] -= delta;
			i--;
		}
		
		while (i >= 0) {
			freqTable[i] += delta;
			i--;
		}
	}
	
	/**
	 * Record a disk access as per the Parker interface specification.
	 */
	public void diskAccess(float period) {
		int ticks = secsToTicks(period);
		
		// Add this idle period to the frequency table and the queue. If the
		// queue is full, remove the oldest idle period
		if ( numPastEvents == NUM_PAST_EVENTS) {
			try {
				updateTable(((Integer)(pastEvents.dequeue())).intValue(), -1);
			} catch (Exception e) {} // We are single-threaded, this won't happen
		} else {
			numPastEvents++;
		}
		pastEvents.enqueue(new Integer(ticks));
		updateTable(secsToTicks(period), 1);
	}
	
	/**
	 * Get the current minimum idle time before it is safe to park the disk 
	 */
	public float getTimeout() {
		// Find the first non negative number (i.e. the ealiest time where it's
		// safe to park)
		// TODO: make this faster (maybe with a heap)?
		// TODO: do the right thing when there's no data recorded.
		for (int i = 0; i < freqTable.length; i++) {
			if (freqTable[i] >= 0) {
				return ticksToSecs(i);
			}
		}
		
		// No safe park timeout found.
		return -1.0f;
	}
}

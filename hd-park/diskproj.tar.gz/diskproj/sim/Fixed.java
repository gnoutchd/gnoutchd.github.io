/**
 * A software simulation of the problematic fixed-timeout mechanism.
 * 
 * @author Daniel Gnoutcheff
 *
 */
public class Fixed implements Parker {

	public void diskAccess(float period) {
		// Disk access data is ignored
	}

	public float getTimeout() {
		// The timeout is a fixed constant.
		return 6.0f;
	}

}

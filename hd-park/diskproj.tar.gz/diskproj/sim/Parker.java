/**
 * Represents classes that implement parking decision algorithms
 * 
 * @author Daniel Gnoutcheff
 *
 */
public interface Parker {
	/**
	 * Record a disk access.
	 * 
	 * @param period the amount of time (in seconds) since the last disk
	 *   access)
	 */
	public void diskAccess(float period);
	
	/**
	 * Get the current minimum idle time, based on any data collected so far.
	 * 
	 * @return the minimum amount of idle time required before we should
	 *   park. Negative values mean we should never park.
	 */
	public float getTimeout();
}

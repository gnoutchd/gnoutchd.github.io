#!/usr/bin/env python

import json, codecs, cgi
from datetime import date

class Registrar(object):
  def __init__(self, json_data):
    self.name = json_data['name']
    self.url = json_data['url']
    if 'region' in json_data:
      self.region = json_data['region']
    else:
      self.region = ''
    if 'notes' in json_data:
      self.notes = json_data['notes']
    else:
      self.notes = ''
    self.support_level = json_data['support-level']

  def __cmp__(self, other):
    support_weights = {'all': 0, 'domain-only': 1, '2level-only': 2}
    if self.support_level != other.support_level:
      return cmp(
        support_weights[self.support_level], 
        support_weights[other.support_level])
    else:
      return cmp(self.name.lower(), other.name.lower())
  
  def name_html(self):
    return u'<td><a href=\"' + self.url + '\">' + \
      cgi.escape(self.name) + u'</a></td>'

  def third_level_support_html(self):
    names = {
      'all':         (u'Yes', u'3level-full'),
      'domain-only': (u'Partial<a href="#no-email">*</a>', 
                              u'3level-domain-only'),
      '2level-only': (u'No',  u'3level-none')}
    (text, html_class) = names[self.support_level]
    return u'<td class=\"' + html_class + u'\">' + text + u'</td>'
  
  def region_html(self):
    return u'<td>' + self.region + u'</td>'

  def notes_html(self):
    return u'<td>' + self.notes + u'</td>'

  def to_html_table_row(self):
    return u'<tr>' + \
      self.name_html() + \
      self.third_level_support_html() + \
      self.region_html() + \
      self.notes_html() + \
      u'</tr>\n'

regs_json = json.load(open('dotname-registrars.json', 'r'), encoding='utf-8')
registrars = [Registrar(reg_json) for reg_json in regs_json]
registrars.sort()

template = codecs.open('template.xhtml', 'r', encoding='utf-8')
registrars_html = codecs.open('index.xhtml', 'w', encoding='utf-8')

def write_table(output_file):
  for registrar in registrars:
    output_file.write(registrar.to_html_table_row())

def write_date(output_file):
  output_file.write(date.today().strftime("%B %d, %Y"))

line = template.readline()
while line != '':
  if '<!-- The list -->' in line:
    write_table(registrars_html)
  elif '<!-- The date -->' in line:
    write_date(registrars_html)
  else:
    registrars_html.write(line)
  line = template.readline()

registrars_html.close()
template.close()

#!/usr/bin/env python3

import urllib.request, json, time, io

regdata_url = 'http://www.verisigninc.com/resources/js/data/registrars.json?rpp=1000000&tld=.name'
output_filename = time.strftime('registrars-dotname-verisign-%Y%m%d.json')

with urllib.request.urlopen(regdata_url) as regdata_infile:
  regdata = json.load(io.TextIOWrapper(regdata_infile, 'utf-8'))

# Ensure that we got everything
if regdata['pageCount'] != 1:
  raise Exception('Downloaded registrar data seems to be incomplete')

# Copy over just the stuff we want
reglist = [{'url': entry['url'], 'name': entry['name']} \
  for entry in regdata['registrars']]

# Dump the data with the indenting we've been using
with open(output_filename, 'w') as reglist_outfile:
  json.dump(reglist, reglist_outfile, indent=1)

print("Dumped Verisign .name registar data to " + output_filename)
